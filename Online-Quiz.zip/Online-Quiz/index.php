<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title> Online Quiz System </title>
        <link rel="stylesheet" type="text/css" href="css/index.css" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
        <link rel="shortcut icon" type="image/png" href="image/logo.png" />
        <style type="text/css">
            body {
                width: 100%;
                background: url(image/book.png) ;
                background-position: center center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }
        </style>
    </head>
    <body>
        <center>
            <div class="intro">
                <h1 class="font-effect-shadow-multiple"> Online Quiz System </h1>
                <a href="user/login.php" class="btn"> Student Login </a> &emsp;
                <a href="lecturer/lecturer_login.php" class="btn"> Lecturer Login </a> &emsp;
                <a href="admin/admin_login.php" class="btn"> Admin Login </a> &emsp;
                <a href="user/register.php" class="btn"> Register </a> &emsp;
            </div>
        </center>
    </body>
</html>