<?php
    include_once '../database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:login.php");
    }
    else
    {
        $email = $_SESSION['email'];
        $id = $_SESSION['id'];
        include_once '../database.php';
    }

     //for top 5 students   
     $card7 = mysqli_query($con, "SELECT * FROM user") or die('Error');
     while ($row = mysqli_fetch_array($card7)) {
         $user_name = $row['user_name'];                        
         
         $card8 = mysqli_query($con, "SELECT user_name, COUNT(*) AS row_count
         FROM history
         GROUP BY user_name
         ORDER BY row_count DESC
         LIMIT 5") or die('Error');                                             
    }

    $userWithHighestRowCount = array(); // Initialize as an empty array
    $username = array(); // Initialize as an empty array

    while ($row = mysqli_fetch_array($card8)) {
        $userWithHighestRowCount[] = $row['row_count']; // Store row counts
        $username[] = $row['user_name']; // Store user names
    }

    array_push($userWithHighestRowCount , $username );

    //for graph2

    $total = array(); // Initialize as an empty array

    for ($a = 1; $a <= 12; $a++) {
        $card9 = mysqli_query($con, "SELECT * FROM history WHERE MONTH(date) = '$a'") or die('Error');
        $rowcount = mysqli_num_rows($card9);
        $total[] = $rowcount; // Store row counts
    }

    array_push($total);

    //for graph 3

    $monthly_quiz = array(); // Initialize as an empty array

    for ($a = 1; $a <= 12; $a++) {
        $card10 = mysqli_query($con, "SELECT * FROM quiz WHERE MONTH(date) = '$a'") or die('Error');
        $rowcount2 = mysqli_num_rows($card10);
        $monthly_quiz[] = $rowcount2; // Store row counts
    }

    array_push($monthly_quiz);

    //for graph 4
    $subject_arr = array();
    $rate = array();
    
    $card11 = mysqli_query($con, "SELECT * FROM subject") or die('Error');
    
    while ($row = mysqli_fetch_array($card11)) {
        $subject = $row['subject'];
        $counter = 0;
        $rowcount3 = mysqli_num_rows($card11);
    
        if (!empty($subject)) {  // Check if subject is not empty
            $card12 = mysqli_query($con, "SELECT * FROM quiz WHERE quiz_subject = '$subject'") or die('Error');
    
            while ($row2 = mysqli_fetch_array($card12)) {
                $quiz_id = $row2['quiz_id'];
                $correct = $row2['correct'];
                $total_question = $row2['total_question'];
    
                $pass = ($correct * $total_question) / 2;
    
                $card13 = mysqli_query($con, "SELECT * FROM rank WHERE quiz_id = '$quiz_id'") or die('Error');
    
                while ($row3 = mysqli_fetch_array($card13)) {
                    if ($row3['score'] >= $pass) {
                        $counter++;
                    }
                }
            }
    
            $subject_arr[] = $subject;
            $rate[] = $counter;
        }
    }
    
    json_encode(array('subject' => $subject_arr, 'rate' => $rate));

    
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard | Online Quiz System</title>
    <link  rel="stylesheet" href="../css/bootstrap.min.css"/>
    <link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
    <link rel="stylesheet" href="../css/welcome.css">
    <link  rel="stylesheet" href="../css/font.css">
    <link rel="stylesheet" href="../css/form.css">
    <script src="js/jquery.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js"  type="text/javascript"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>    


</head>

<body>

<!-- Navigation Menu for Large Screens (Laptops) -->
<nav class="navbar navbar-default title1 hidden-sd hidden-xs" id="tablet">
    <div class="container-fluid">
        <div class="navbar-header">
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Hidden dialog box -->
        <div id="profile-dialog" class="dialog-box">
            <button id="close-dialog" class="close-button">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
            </button>
            <br/>
            <p>Admin ID : <?php echo $id; ?></p>
            <br/>
            <center><button id="view-profile">View Profile</button></center>
        </div>


<!-- Navigation Menu for Small Screens (Mobile) -->
<nav class="navbar navbar-default title1 hidden-lg">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mobile-menu" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        
        <div class="collapse navbar-collapse" id="mobile-menu">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
                <li><a href="admin_dashboard.php" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home<span class="sr-only">(current)</span></a></li>
                <li><a href="announcement.php" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                <li><a href="student.php" class="hover-underline-animation"><span class="glyphicon glyphicon-education" aria-hidden="true"></span>&nbsp;Student</a></li>
                <li><a href="lecturer.php" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Lecturer</a></li>
                <li><a href="history.php" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                <li><a href="ranking.php" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                <li><a href="question_bank.php" class="hover-underline-animation"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
                <li><a href="subject.php" class="hover-underline-animation"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
                <li><a href="quizzes.php" class="hover-underline-animation"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                <li><a href="admin_chat.php" class a="hover-underline-animation"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>
                <li><a href="admin_profile.php" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
            </ul>
        </div>
    </div>
</nav> 

<div class="container">
        <div class="row">
            <div class="col-md-2 hidden-sd hidden-xs hidden-md" id="tablet">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav flex-column navbar-left">
                    <li><a href="admin_dashboard.php" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home<span class="sr-only">(current)</span></a></li>
                    <li><a href="announcement.php" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                    <li><a href="student.php" class="hover-underline-animation"><span class="glyphicon glyphicon-education" aria-hidden="true"></span>&nbsp;Student</a></li>
                    <li><a href="lecturer.php" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Lecturer</a></li>
                    <li><a href="history.php" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                    <li><a href="ranking.php" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                    <li><a href="question_bank.php" class="hover-underline-animation"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
                    <li><a href="subject.php" class="hover-underline-animation"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
                    <li><a href="quizzes.php" class="hover-underline-animation"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                    <li><a href="admin_chat.php" class="hover-underline-animation"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>
                    <li><a href="admin_profile.php" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                </ul>
            </div>
            </div>
    
    <div class="col-md-10">
    <span class="title1"><h1 style="padding:10px;"><center>Welcome to Online Quiz System</center></h1></span>

    <div class="row" style="margin-top:20px">
        <div class="col-md-4">
            <h3 style='padding-bottom:20px; padding-left: 10px;'>Latest Announcement</h3>
        </div>
    </div>

    <div class="row">
    <div class="card" style="margin:20px; margin-top:-15px;">
       <div class="table-responsive">
       <table class="table table-striped title1" style="margin-bottom:0px;">
            <thead>
            <tr>
                <td><center><b>No.</b></center></td>
                <td><center><b>Subject</b></center></td>
                <td><center><b>Announcement</b></center></td>
                <td><center><b>Status</b></center></td>
                <td><center><b>Date</b></center></td>
            </tr>
            </thead>
        <?php

        $no = 1;
        $result = mysqli_query($con,"SELECT * FROM announcement ORDER BY date DESC LIMIT 3") or die('Error');
        while($row = mysqli_fetch_array($result)) 
        {
           $subject = $row['subject'];
           $announcement = $row['announcement'];
           $status = $row['status'];
           $date = $row['date'];
           $formattedDate = date("Y-m-d", strtotime($date));

           echo '<tr><td><center>'.$no.'</center></td>
           <td><center>'.$subject.'</center></td>
           <td><center>'.$announcement.'</center></td>
           <td><center>'.$status.'</center></td>
           <td><center>'.$formattedDate.'</center></td>
           </tr>';

           $no++;
        }
       ?>
       </table></div></div>


    </div>

    <!-- for data card -->
    <div class="row">
        <div class="col-md-3">
            <div class="card" style="background-color: #fddfdf">
                <?php     
                    $card = mysqli_query($con, "SELECT * FROM user") or die('Error');
                    $rowcount = mysqli_num_rows($card);
                    $student = $rowcount;
                    
                    echo "<center><h2 style='color: black;'>$student</h2>";                    
                ?>
                <p class="word"><span class="glyphicon glyphicon-education" aria-hidden="true"></span>&nbsp;Total Student</p></center>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card" style="background-color: #fcf7de">
                <?php     
                    $card2 = mysqli_query($con, "SELECT * FROM lecturer") or die('Error');
                    $rowcount = mysqli_num_rows($card2);
                    $lecturer = $rowcount;
                    
                    echo "<center><h2 style='color: black;'>$lecturer</h2>";                    
                ?>
                <p class="word"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Total Lecturer</p></center>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card" style="background-color: #defde0">
            <?php     
                // Get the current year and month
                $currentYear = date('Y');
                $currentMonth = date('m');

                // Construct the first day of the current month in 'Y-m-d' format
                $firstDayOfCurrentMonth = date("$currentYear-$currentMonth-01");

                // Construct the last day of the current month in 'Y-m-d' format
                $lastDayOfCurrentMonth = date("$currentYear-$currentMonth-31");

                // Modify your SQL query to filter by date within the current month
                $query = "SELECT * FROM chat_history WHERE date >= '$firstDayOfCurrentMonth' AND date <= '$lastDayOfCurrentMonth'";
                $card3 = mysqli_query($con, $query) or die('Error');

                $rowcount = mysqli_num_rows($card3);
                $chathistory = $rowcount;

                echo "<center><h2 style='color: black;'>$chathistory</h2>";                    
                ?>
                <p class="word"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Total messages</p></center>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card" style="background-color: #def3fd">
                <?php     
                    $card4 = mysqli_query($con, "SELECT * FROM subject") or die('Error');
                    $rowcount = mysqli_num_rows($card4);
                    $subject = $rowcount;
                    
                    echo "<center><h2 style='color: black;'>$subject</h2>";                    
                ?>
                <p class="word"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Total Subject</p></center>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card" style="background-color: #f0defd">
                <?php     
                    $card5 = mysqli_query($con, "SELECT * FROM quiz") or die('Error');
                    $rowcount = mysqli_num_rows($card5);
                    $quiz = $rowcount;
                    
                    echo "<center><h2 style='color: black;'>$quiz</h2>";                    
                ?>
                <p class="word"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Total Quiz</p></center>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card" style="background-color: #ffefc9">
                <?php     
                    $card6 = mysqli_query($con, "SELECT * FROM questions") or die('Error');
                    $rowcount = mysqli_num_rows($card6);
                    $questions = $rowcount;
                    
                    echo "<center><h2 style='color: black;'>$questions</h2>";                    
                ?>
                <p class="word"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank </p></center>
            </div>
        </div>
    </div>

    <!-- graph part -->

    <div class="row">
        <div class="col-md-6">
            <div class="card">
            <canvas id="myChart" style="width:100%;max-width:700px; height:500px; padding:10px;"></canvas>

            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
            <canvas id="myChart2" style="width:100%;max-width:700px; height:500px; padding:10px;"></canvas>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-md-6">
            <div class="card">
            <canvas id="myChart3" style="width:100%;max-width:700px; height:500px; padding:10px;"></canvas>

            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
            <canvas id="myChart4" style="width:100%;max-width:700px; height:500px; padding:10px;"></canvas>
            </div>
        </div>
    </div>



<script>
// Get references to the elements
const profileIcon = document.getElementById('profile-icon');
const profileDialog = document.getElementById('profile-dialog');
const closeDialogBtn = document.getElementById('close-dialog'); // Added close button reference
const viewProfileBtn = document.getElementById('view-profile');

// Add a click event handler to the profile icon
profileIcon.addEventListener('click', () => {
    // Display the dialog box
    profileDialog.style.display = 'block';
});

// Add a click event handler to the "View Profile" button
viewProfileBtn.addEventListener('click', () => {
    window.location.replace('admin_profile.php');
});

// Add a click event handler to the "Close" button
closeDialogBtn.addEventListener('click', () => {
    // Close the dialog
    profileDialog.style.display = 'none';
});
</script>


<script>

    // graph 1
    var studentNames = <?= json_encode($username); ?>;
    var scores = <?= json_encode($userWithHighestRowCount); ?>;
    barColors = ["#fddfdf", "#f5c1cf", "#fddfdf", "#f5c1cf", "#fddfdf"];

    var ctx = document.getElementById('myChart').getContext('2d');

    var data = {
        labels: studentNames, // Student names on the y-axis
        datasets: [{
            label: 'Total scores',
            data: scores, // Scores on the x-axis
            backgroundColor: barColors,
            borderColor: '#ffadad',
            borderWidth: 1
        }]
    };

    var myChart = new Chart(ctx, {
        type: 'bar',
        data: data,
        options: {
            responsive: true,
            scales: {
                x: { 
                    suggestedMin: 0,
                    suggestedMax: 10
                },
                y: {
                    suggestedMin: 0,
                    suggestedMax: 10
                }
            },
            title: {
                display: true,
                text: "Top 5 students with highest attendance",
                fontSize: 20,
                fontFamily: 'Georgia, serif',
                fontColor: "#0087ca",
                fontStyle: "bold"
            }
        }
    });

      //graph 2
      var total = <?= json_encode($total); ?>;
      
      // Get the canvas element
      var ctx = document.getElementById('myChart2').getContext('2d');

      // Define the chart data
      var data = {
         labels: ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
         datasets: [{
            label: 'Numnber of students',
            data: total,
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
         }]
      };

      // Create the chart
      var myChart2 = new Chart(ctx, {
         type: 'radar',
         data: data,
         options: {
            responsive: true,
            scales: {
               y: {
                  beginAtZero: true
               }
            },
            title: {
                display: true,
                text: "Total participants of every month",
                fontSize: 20,
                fontFamily: 'Georgia, serif',
                fontColor: "#0087ca",
                fontStyle: "bold"
            }
         }
      });
         
        //graph 3
        var monthly_quiz = <?= json_encode($monthly_quiz); ?>;

         // Get the canvas element
        // Get the canvas element
        var ctx = document.getElementById('myChart3').getContext('2d');

        // Define the chart data
        var data = {
        labels: ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'],
        datasets: [{
            label: 'Total quizzes uploaded',
            data: monthly_quiz,
            backgroundColor: '#c5a3ff',
            borderColor: '#b28dff',
            borderWidth: 1,
            fill: false,
            lineTension: 0,
        }]
        };

        // Create the chart
        var myChart3 = new Chart(ctx, {
        type: 'line',
        data: data,
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true // Start the y-axis at zero
                },
            },
            title: {
                display: true,
                text: "Monthly quizzes uploaded report",
                fontSize: 20,
                fontFamily: 'Georgia, serif',
                fontColor: "#0087ca",
                fontStyle: "bold"
            }
        }
        });

        //graph 4
        var chartData = <?php echo json_encode(array('subject' => $subject_arr, 'rate' => $rate)); ?>;
        var subject = chartData.subject;
        var counter = chartData.rate;

        // Get the canvas element
        var ctx = document.getElementById('myChart4').getContext('2d');

        // Define the chart data
        var data = {
            labels: subject,
            datasets: [{
                label: 'Passing rate',
                data: counter,
                backgroundColor: '#fcf7de',
                borderColor: '#ffcfb0',
                borderWidth: 1
            }]
        };

        // Create the chart
        var myChart4 = new Chart(ctx, {
            type: 'line', 
            data: data,
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                title: {
                    display: true,
                    text: "Passing rate of subject",
                    fontSize: 20,
                    fontFamily: 'Georgia, serif',
                    fontColor: "#0087ca",
                    fontStyle: "bold"
                }
            }
        });

    </script>

</body>
</html>