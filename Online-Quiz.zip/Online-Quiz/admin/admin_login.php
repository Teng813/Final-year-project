<?php

    include_once('../database.php');

    session_start();

    if(isset($_SESSION["email"]))
    {
        session_destroy();
    }

    if (!isset($_SERVER['PHP_AUTH_USER'])) {
        header('WWW-Authenticate: Basic realm="My Realm"');
        header('HTTP/1.0 401 Unauthorized');
        echo 'Text to send if user hits Cancel button';
        exit;
    } else {

        $result = mysqli_query($con,"SELECT * FROM admin") or die('Error');
        while($row = mysqli_fetch_array($result)){
            $email = $row['admin_email'];
            $id = $row['admin_id'];
            $password = $row['admin_password'];
        }

        //from database
        if ($_SERVER['PHP_AUTH_USER'] == $email && $_SERVER['PHP_AUTH_PW'] == $password) {
            header('Location: admin_dashboard.php');
     
            $_SESSION["email"] = $email;
            $_SESSION["id"] = $id;	
            
            session_start();
        }
    }
?>
