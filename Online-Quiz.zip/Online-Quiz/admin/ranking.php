<?php
    include_once '../database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:login.php");
    }
    else
    {
        $email = $_SESSION['email'];
        $id = $_SESSION['id'];
        include_once '../database.php';
    }
    //Delete ranking
    if(@$_GET['q']== 'rmrank') 
    {
        $rank_id=@$_GET['rank_id'];
        $result = mysqli_query($con,"SELECT * FROM rank WHERE rank_id='$rank_id' ") or die('Error');
        while($row = mysqli_fetch_array($result)) 
        {
        $r1 = mysqli_query($con,"DELETE FROM rank WHERE rank_id='$rank_id'") or die('Error');
        }

        echo"<script>alert('You have successfully delete a rank!'); window.location.replace('ranking.php'); </script>";			
    } 
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ranking | Online Quiz System</title>
    <link  rel="stylesheet" href="../css/bootstrap.min.css"/>
    <link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
    <link rel="stylesheet" href="../css/welcome.css">
    <link  rel="stylesheet" href="../css/font.css">
    <link rel="stylesheet" href="../css/form.css">
    <script src="js/jquery.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js"  type="text/javascript"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>   
</head>

<body>

  <!-- Navigation Menu for Large Screens (Laptops) -->
<nav class="navbar navbar-default title1  hidden-sd hidden-xs" id="tablet">
    <div class="container-fluid">
        <div class="navbar-header">
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Hidden dialog box -->
        <div id="profile-dialog" class="dialog-box">
            <button id="close-dialog" class="close-button">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
            </button>
            <br/>
            <p>Admin ID : <?php echo $id; ?></p>
            <br/>
            <center><button id="view-profile">View Profile</button></center>
        </div>


<!-- Navigation Menu for Small Screens (Mobile) -->
<nav class="navbar navbar-default title1 hidden-md hidden-lg">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mobile-menu" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        
        <div class="collapse navbar-collapse" id="mobile-menu">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
                <li><a href="admin_dashboard.php" class="hover-underline-animation" ><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                <li><a href="announcement.php" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                <li><a href="student.php" class="hover-underline-animation"><span class="glyphicon glyphicon-education" aria-hidden="true"></span>&nbsp;Student</a></li>
                <li><a href="lecturer.php" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Lecturer</a></li>
                <li><a href="history.php" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                <li><a href="ranking.php" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                <li><a href="question_bank.php" class="hover-underline-animation"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
                <li><a href="subject.php" class="hover-underline-animation"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
                <li><a href="quizzes.php" class="hover-underline-animation"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                <li><a href="admin_chat.php" class a="hover-underline-animation"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>
                <li><a href="admin_profile.php" class="hover-underline-animation" ><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                <li><a href="admin_profile.php" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
            </ul>
        </div>
    </div>
</nav> 

<div class="container">
        <div class="row">
            <div class="col-md-2 hidden-sd hidden-xs" id="tablet">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav flex-column navbar-left">
                    <li><a href="admin_dashboard.php" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                    <li><a href="announcement.php" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                    <li><a href="student.php" class="hover-underline-animation"><span class="glyphicon glyphicon-education" aria-hidden="true"></span>&nbsp;Student</a></li>
                    <li><a href="lecturer.php" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Lecturer</a></li>
                    <li><a href="history.php" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                    <li><a href="ranking.php" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                    <li><a href="question_bank.php" class="hover-underline-animation"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
                    <li><a href="subject.php" class="hover-underline-animation"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
                    <li><a href="quizzes.php" class="hover-underline-animation"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                    <li><a href="admin_chat.php" class="hover-underline-animation"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>
                    <li><a href="admin_profile.php" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                </ul>
            </div>
            </div>
    
            <div class="col-md-10">
            <div class="row">
                <span class="title1"><h1 style="padding:10px;"><center>Ranking</center></h1></span>
                <div class="col-md-1"></div><div class="col-md-7" style="margin-top:20px;">
                <form action="ranking.php" method="POST">
                    <div class="form-group">
                        <label for="quiz" style="color: #0087ca;"><b>Please select a quiz :</b></label>
                        <select id="quiz" name="quiz" class="form-control" required>
                            <option value="">Please select a quiz</option>
                            <?php
                                $result = mysqli_query($con,"SELECT * FROM quiz") or die('Error');
                                
                                while($row = mysqli_fetch_array($result)){
                                    $quiz_subject = $row['quiz_subject'];
                                    $quiz_title = $row['quiz_title'];
                                    echo'<option value="'.$quiz_subject.' - '.$quiz_title.'"> '.$quiz_subject.' - '.$quiz_title.'</option>';

                                }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-1">
                    <button name="submit" id="submit" class="btn btnStyle btn-block" style="margin:45px; width:100px; text-align:center;">Submit</button>
                </div>

            </form>
            </div>
                        
    <?php

        if(isset($_POST['submit'])){

        //for rank number increment
        $rank = 1;

        $selectedAns = $_POST['quiz'];
        list($quiz_subject, $quiz_title) = explode(' - ', $selectedAns);

        echo  '<div class="panel title" style="margin-top:10px;">
        <div class="table-responsive">
        <table class="table table-striped title1">
            <thead>
                <tr style="color: #0087ca;">
                    <td><center><b>Rank</b></center></td>
                    <td><center><b>Quiz title</b></center></td>
                    <td><center><b>Student ID</b></center></td>
                    <td><center><b>Student Name</b></center></td>
                    <td><center><b>Student Email</b></center></td>
                    <td><center><b>Score</b></center></td>
                    <td><center><b>Action</b></center></td>
                </tr>
            </thead>';

        $q2 = mysqli_query($con, "SELECT * FROM quiz WHERE quiz_title='$quiz_title' AND quiz_subject='$quiz_subject'") or die('Error223');
        while ($row = mysqli_fetch_array($q2)) {
            $quiz_id = $row['quiz_id'];

            $currentYear = date("Y");  
            
            $q = mysqli_query($con, "SELECT * FROM rank WHERE quiz_id='$quiz_id' AND YEAR(date) = '$currentYear' ORDER BY score DESC") or die('Error223');
            while ($row = mysqli_fetch_array($q)) {
                $rank_id = $row['rank_id'];
                $user_id = $row['user_id'];
                $user_email = $row['user_email'];
                $user_name = $row['user_name'];
                $score = $row['score'];
                $quiz_id = $row['quiz_id'];


            echo '<tr data-quiz="'.$quiz_subject.' - '.$quiz_title.'">
                <td style="color:red"><center><b>'.$rank.'</b></center></td>
                <td><center>'.$quiz_subject.' - '.$quiz_title.'</center></td>
                <td><center>' . $user_id . '</center></td>
                <td><center>' . $user_name . '</center></td>
                <td><center>' . $user_email . '</center></td>
                <td><center>' . $score . '</center></td>
                <td><center><b><a href="ranking.php?q=rmrank&rank_id='.$rank_id.'" class="btn sub1"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span>&nbsp;<span class="title1"><b>Archive</b></span></a></b></center></td>

            </tr>';

            $rank++;
        }
    }
        echo '</table></div></div>';

    }
      
        
    ?>

</div>

<script>
// Get references to the elements
const profileIcon = document.getElementById('profile-icon');
const profileDialog = document.getElementById('profile-dialog');
const closeDialogBtn = document.getElementById('close-dialog'); // Added close button reference
const viewProfileBtn = document.getElementById('view-profile');

// Add a click event handler to the profile icon
profileIcon.addEventListener('click', () => {
    // Display the dialog box
    profileDialog.style.display = 'block';
});

// Add a click event handler to the "View Profile" button
viewProfileBtn.addEventListener('click', () => {
    window.location.replace('admin_profile.php');
});

// Add a click event handler to the "Close" button
closeDialogBtn.addEventListener('click', () => {
    // Close the dialog
    profileDialog.style.display = 'none';
});

</script>
   

</body>
</html>