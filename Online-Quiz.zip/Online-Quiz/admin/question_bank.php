<?php
    include_once '../database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:login.php");
    }
    else
    {
        $email = $_SESSION['email'];
        $id = $_SESSION['id'];
        include_once '../database.php';
    }

    //Delete question
    if(@$_GET['q']== 'rmquestion') 
    {
      $question_id=@$_GET['question_id'];
      $result = mysqli_query($con,"SELECT * FROM questions WHERE question_id='$question_id' ") or die('Error');
      while($row = mysqli_fetch_array($result)) 
      {
        $question = $row['question'];
        $r1 = mysqli_query($con,"DELETE FROM questions WHERE question_id='$question_id'") or die('Error');
        $r2 = mysqli_query($con,"DELETE FROM options WHERE question_id='$question_id' ") or die('Error');
        $r3 = mysqli_query($con,"DELETE FROM answer WHERE question_id='$question_id' ") or die('Error');
        $r4 = mysqli_query($con, "DELETE FROM quiz WHERE question LIKE '%$question_id%'") or die('Error');

      }
      
      echo"<script>alert('You have successfully delete a question!'); window.location.replace('question_bank.php'); </script>";			
    } 
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Question Bank | Online Quiz System</title>
    <link  rel="stylesheet" href="../css/bootstrap.min.css"/>
    <link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
    <link rel="stylesheet" href="../css/welcome.css">
    <link  rel="stylesheet" href="../css/font.css">
    <link rel="stylesheet" href="../css/form.css">
    <script src="js/jquery.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js"  type="text/javascript"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>    
</head>

<body>

<!-- Navigation Menu for Large Screens (Laptops) -->
<nav class="navbar navbar-default title1  hidden-sd hidden-xs" id="tablet">
    <div class="container-fluid">
        <div class="navbar-header">
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Hidden dialog box -->
        <div id="profile-dialog" class="dialog-box">
            <button id="close-dialog" class="close-button">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
            </button>
            <br/>
            <p>Admin ID : <?php echo $id; ?></p>
            <br/>
            <center><button id="view-profile">View Profile</button></center>
        </div>


<!-- Navigation Menu for Small Screens (Mobile) -->
<nav class="navbar navbar-default title1 hidden-md hidden-lg">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mobile-menu" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        
        <div class="collapse navbar-collapse" id="mobile-menu">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
                <li><a href="admin_dashboard.php" class="hover-underline-animation" ><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home<span class="sr-only">(current)</span></a></li>
                <li><a href="announcement.php" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                <li><a href="student.php" class="hover-underline-animation"><span class="glyphicon glyphicon-education" aria-hidden="true"></span>&nbsp;Student</a></li>
                <li><a href="lecturer.php" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Lecturer</a></li>
                <li><a href="history.php" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                <li><a href="ranking.php" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                <li><a href="question_bank.php" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
                <li><a href="subject.php" class="hover-underline-animation"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
                <li><a href="quizzes.php" class="hover-underline-animation"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                <li><a href="admin_chat.php" class a="hover-underline-animation"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>
                <li><a href="admin_profile.php" class="hover-underline-animation" ><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                <li><a href="admin_profile.php" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
            </ul>
        </div>
    </div>
</nav> 

<div class="container">
        <div class="row">
            <div class="col-md-2 hidden-sd hidden-xs" id="tablet">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav flex-column navbar-left">
                    <li><a href="admin_dashboard.php" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home<span class="sr-only">(current)</span></a></li>
                    <li><a href="announcement.php" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                    <li><a href="student.php" class="hover-underline-animation"><span class="glyphicon glyphicon-education" aria-hidden="true"></span>&nbsp;Student</a></li>
                    <li><a href="lecturer.php" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Lecturer</a></li>
                    <li><a href="history.php" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                    <li><a href="ranking.php" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                    <li><a href="question_bank.php" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
                    <li><a href="subject.php" class="hover-underline-animation"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
                    <li><a href="quizzes.php" class="hover-underline-animation"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                    <li><a href="admin_chat.php" class="hover-underline-animation"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>
                    <li><a href="admin_profile.php" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                </ul>
            </div>
            </div>
    
            <div class="col-md-10">
    <div class="row">
        <span class="title1"><h1 style="padding:10px;"><center>Question Bank</center></h1></span>
        <div class="col-md-3"></div><div class="col-md-6 text-center" style="margin-top:20px;">
            <div class="form-group">
                <label for="subjectFilter" style="color: #0087ca;"><b>Filter by Subject :</b></label>
                <select id="subjectFilter" class="form-control">
                    <option value="all">All Subjects</option>
                    <?php
                        $result = mysqli_query($con,"SELECT * FROM subject") or die('Error');
                        
                        while($row = mysqli_fetch_array($result)){

                            $quiz_subject = $row['subject'];
                            echo'<option value="'.$quiz_subject.'"> '.$quiz_subject.'</option>';

                        }
                    ?>
                </select>
            </div>
        </div>
    </div>
        
    
    <?php
        //show questions with delete button
        $result = mysqli_query($con,"SELECT * FROM questions") or die('Error');
        echo  '<div class="panel">
        <div class="table-responsive">
        <table class="table table-striped title1" id="myTable">
            <thead>
                <tr style="color: #0087ca;">
                    <td><center><b>Question ID</b></center></td>
                    <td><center><b>Question</b></center></td>
                    <td><center><b>Subject</b></center></td>
                    <td><center><b>Number of choices</b></center></td>
                    <td><center><b>Choices</b></center></td>
                    <td><center><b>Action</b></center></td>
                </tr>
            </thead>';

        // Outer loop to retrieve questions
        while ($row = mysqli_fetch_array($result)) {
            $question_id = $row['question_id'];
            $subject = $row['subject'];
            $question = $row['question'];
            $choice = $row['choice'];

            // Initialize an empty string to store the concatenated options
            $final_choice = '';

            // Query to get the answers from the "options" table for the current question
            $result2 = mysqli_query($con, "SELECT * FROM options WHERE question_id = '$question_id'") or die('Error');

            while ($optionRow = mysqli_fetch_array($result2)) {
                $option = $optionRow['option'];

                $final_choice .= $option . ', ';
            }

            // Remove the trailing comma and space
            $final_choice = rtrim($final_choice, ', ');

            echo '<tr data-subject="' . $subject . '">
                <td><center>'.$question_id.'</center></td>
                <td><center>'.$question.'</center></td>
                <td><center>'.$subject.'</center></td>
                <td><center>'.$choice.'</center></td>
                <td><center>'.$final_choice.'</center></td>
                <td><center><b><a href="question_bank.php?q=rmquestion&question_id='.$question_id.'" class="btn sub1"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span>&nbsp;<span class="title1"><b>Remove</b></span></a></b></center></td>
            </tr>';
        }

        $c = 0;
        echo '</table></div></div>';

    ?>
    </div>   

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {
    //Function to apply the subject filter
    function applySubjectFilter(selectedSubject) {
        $("#myTable tbody tr").show(); 

        if (selectedSubject !== "all") {
            // Hide rows when selected one subject
            $("#myTable tbody tr:not([data-subject='" + selectedSubject + "'])").hide();
        }
    }

    // Add a change event to the subject filter
    $("#subjectFilter").change(function() {
        var selectedSubject = $(this).val();
        applySubjectFilter(selectedSubject);
    });

    // Initial filter based on the default selection
    var defaultSubject = $("#subjectFilter").val();
    applySubjectFilter(defaultSubject);
});
</script>

<script>
// Get references to the elements
const profileIcon = document.getElementById('profile-icon');
const profileDialog = document.getElementById('profile-dialog');
const closeDialogBtn = document.getElementById('close-dialog'); // Added close button reference
const viewProfileBtn = document.getElementById('view-profile');

// Add a click event handler to the profile icon
profileIcon.addEventListener('click', () => {
    // Display the dialog box
    profileDialog.style.display = 'block';
});

// Add a click event handler to the "View Profile" button
viewProfileBtn.addEventListener('click', () => {
    window.location.replace('admin_profile.php');
});

// Add a click event handler to the "Close" button
closeDialogBtn.addEventListener('click', () => {
    // Close the dialog
    profileDialog.style.display = 'none';
});

</script>

</body>
</html>