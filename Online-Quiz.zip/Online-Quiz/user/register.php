<?php
include("../database.php");
session_start();

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $user_number = $_POST['user_number'];
	$confirm_password = $_POST['confirm_password'];

	if($password == $confirm_password){

		if (
			filter_var($email, FILTER_VALIDATE_EMAIL) &&
			strlen($confirm_password) >= 8 &&
			strlen($confirm_password) <= 20 &&
			preg_match('/^(?=.*[A-Z])(?=.*\d)/', $confirm_password)  // Check for at least one uppercase letter and one number
		) {

		$email = mysqli_real_escape_string($con, $email);
		$user_password = password_hash($confirm_password, PASSWORD_DEFAULT);

		// Check if the email is already registered
		$query2 = "SELECT * FROM user WHERE user_email = '$email'";
		$result = mysqli_query($con, $query2);

		if (mysqli_num_rows($result) > 0) {
			echo "<script>alert('Sorry.. This email is already registered!'); window.location.href = 'login.php';</script>";
		} else {
			// Add the user to the database
			$query = "INSERT INTO user (user_id, user_name, user_email, user_password, user_number, user_image) VALUES ('', '$name', '$email', '$user_password', '$user_number', ' ')";

			if (mysqli_query($con, $query)) {
				echo "<script>alert('You have successfully registered an account!'); window.location.href = 'login.php';</script>";
			} else {
				echo "<script>alert('Registration failed. Please try again later.'); window.location.href = 'register.php';</script>";
			}
		}
	}else {
		echo"<script>alert('Validation failed: Email, password length, uppercase letter, and number requirements not met.'); </script>";
	}
	}
	else{
		echo"<script>alert('Password and Confirm Password not match! Please try again!'); </script>";

	}
}
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Register | Online Quiz System</title>
		<link  rel="stylesheet" href="../css/bootstrap.min.css"/>
		<link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
		<link rel="stylesheet" href="../css/welcome.css">
		<link  rel="stylesheet" href="../css/font.css">
		<link rel="stylesheet" href="../css/form.css">
		<script src="js/jquery.js" type="text/javascript"></script>
		<script src="js/bootstrap.min.js"  type="text/javascript"></script>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>   
        <style type="text/css">
            body{
                  width: 100%;
                  background: url(../image/book.png) ;
                  background-position: center center;
                  background-repeat: no-repeat;
                  background-attachment: fixed;
                  background-size: cover;
                }
          </style>
	</head>

	<body>
	<section class="login first grey">
			<div class="container">
			<center><img src="../image/logo.png" alt="Logo" width="100" height="100" style="padding-top:0px;">
			<h1 class="font-effect-shadow-multiple" style="padding-bottom: 15px;">Online Quiz System</h1></center>	
				<div class="box-wrapper">						
					<div class="box box-border">
						<div class="box-body">
						<center><h2>Register</h2></center><br/>
							<form method="post" action="register.php" enctype="multipart/form-data">
                                <div class="form-group">
									<label>Enter Your Name : </label>
									<input type="text" name="name" class="form-control" required />
								</div>
								<div class="form-group">
									<label>Enter Your Email : </label>
									<input type="email" name="email" class="form-control" required />
								</div>
								<div class="form-group">
									<label>Enter Your Phone Number (number only) : </label>
									<input type="number" name="user_number" class="form-control" required />
								</div>
								<div class="form-group">
									<label>Enter Your Password : </label>
									<input type="password" name="password" class="form-control" required />
                                </div>

								<div class="form-group">
									<label>Please Confirm Your Password : </label>
									<input type="password" name="confirm_password" class="form-control" required />
                                </div>
                                
								<div class="form-group text-right">
									<button class="btn btnStyle btn-block" name="submit">Register</button>
								</div>

								<div class="form-group text-center">
									<span class="text-muted">Already have an account? <a href="login.php">Login </a> Here..</span> 
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</section>

	</body>
</html>