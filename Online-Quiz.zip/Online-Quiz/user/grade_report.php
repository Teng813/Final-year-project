<?php
require('../fpdf/fpdf.php');

if (isset($_POST['submit'])) {
    // Get form data
    $user_name = $_POST['user_name']; 
    $his_id = $_POST['his_id'];
    $user_id = $_POST['user_id'];
    $user_email = $_POST['user_email'];
    $quiz_id = $_POST['quiz_id'];
    $score = $_POST['score'];
    $correct_no = $_POST['correct_no'];
    $wrong_no = $_POST['wrong_no'];
    $attempt = $_POST['attempt'];
    $quiz_title = $_POST['quiz_title'];
    $quiz_subject = $_POST['quiz_subject'];
    $diff_level = $_POST['diff_level'];
    $date = $_POST['date'];

    // Create a new FPDF instance
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 18);

    // Get the dimensions of the page
    $pageWidth = $pdf->GetPageWidth();

    // Define the dimensions of the image
    $imageWidth = 60;  // Adjust this value as needed

    // Calculate the X and Y coordinates to center the image
    $imageX = ($pageWidth - $imageWidth) / 2;

    // Add the image at the calculated position
    $pdf->Image('../image/logo.png', 10 , 10 , 20 , 20 ,'PNG');
    $pdf->Cell(255, 15, '' , 0, 1); //end of line

    $pdf->Cell(25	,10,'',0,1);//end of line


    $pdf->Cell(170, 8, 'Online Quiz System', 0, 0);
    $pdf->Cell(255, 8, $his_id, 0, 1); //end of line

	$pdf->Cell(170, 8, 'Summary of grade report', 0, 0);
    $pdf->Cell(255, 8, '', 0, 1); //end of line

    //set font to arial, regular, 14pt
    $pdf->SetFont('Arial', '', 14);

    $pdf->Cell(170, 5, '', 0, 0);
    $pdf->Cell(255, 5, '' , 0, 1); //end of line

    $pdf->Cell(130, 8, "Student name: $user_name", 0, 0); // Adjust the X-coordinate here
    $pdf->Cell(255, 8, 'Date and time : ', 0, 1); //end of line

    $pdf->Cell(130	,8, "Student email : $user_email " ,0,0);
    $pdf->Cell(255	,8, $date ,0,1);//end of line

    $pdf->Cell(25	,5,'',0,1);//end of line

    $pdf->Cell(130	,8, "Quiz ID : $quiz_id " ,0,0);
    $pdf->Cell(255	,8, '' ,0,1);//end of line

    $pdf->Cell(130	,8, "Quiz Title : $quiz_title " ,0,0);
    $pdf->Cell(255	,8, '' ,0,1);//end of line

    $pdf->Cell(130	,8, "Quiz Subject : $quiz_subject " ,0,0);
    $pdf->Cell(255	,8, '' ,0,1);//end of line

    $pdf->Cell(130	,8, "Difficulty level ( out of 10 ) : $diff_level " ,0,0);
    $pdf->Cell(255	,8, '' ,0,1);//end of line

    $pdf->Cell(130	,8, "Number of attempt : $attempt " ,0,0);
    $pdf->Cell(255	,8, '' ,0,1);//end of line

    //make a dummy empty cell as a vertical spacer
    $pdf->Cell(189	,5,'',0,1);//end of line

    //contents
    $pdf->SetFont('Arial','B',14);

    $pdf->Cell(185	,8,'Summary',1,1);

    $pdf->SetFont('Arial','',14);

    $pdf->Cell(145	,8,'Number of correct answers : ',1,0);
    $pdf->Cell(40	,8, $correct_no ,1,1);

    $pdf->Cell(145	,8,'Number of wrong answers : ',1,0);
    $pdf->Cell(40	,8, $wrong_no ,1,1);

    $pdf->SetFont('Arial','B',14);

    $pdf->Cell(145	,8,'Total marks  : ',1,0);
    $pdf->Cell(40	,8, $score ,1,1);
    
    // Output the PDF as a download
    $pdf->Output('D', 'grade_report.pdf');

    // Exit the script
    exit();
}
?>