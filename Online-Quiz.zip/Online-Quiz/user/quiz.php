<?php
    include_once '../database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:../login.php");
    }
    else
    {
        $name = $_SESSION['name'];
        $email = $_SESSION['email'];
        $id = $_SESSION['id'];
        include_once '../database.php';
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>All Quiz | Online Quiz System</title>
    <link  rel="stylesheet" href="../css/bootstrap.min.css"/>
    <link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
    <link rel="stylesheet" href="../css/welcome.css">
    <link  rel="stylesheet" href="../css/font.css">
    <link rel="stylesheet" href="../css/form.css">
    <script src="js/jquery.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
    <script src="js/bootstrap.min.js"  type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>   
   
</head>
<body>

  <!-- Navigation Menu for Large Screens (Laptops) -->
  <nav class="navbar navbar-default title1 hidden-sd hidden-xs" id="tablet">
    <div class="container-fluid">
        <div class="navbar-header">
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Hidden dialog box -->
        <div id="profile-dialog" class="dialog-box">
            <button id="close-dialog" class="close-button">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
            </button>
            <br/>
            <p>Student ID : <?php echo $id; ?></p>
            <h3><?php echo $name; ?></h3>
            <br/>
            <center><button id="view-profile">View Profile</button></center>
        </div>


<!-- Navigation Menu for Small Screens (Mobile) -->
<nav class="navbar navbar-default title1 hidden-lg">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mobile-menu" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        
        <div class="collapse navbar-collapse" id="mobile-menu">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
                <li><a href="welcome.php" class="hover-underline-animation" ><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                <li><a href="announcement.php" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                <li><a href="quiz.php" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                <li><a href="history.php" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                <li><a href="rank.php" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                <li><a href="lecturer.php" class="hover-underline-animation"><span class="glyphicon glyphicon-blackboard" aria-hidden="true"></span>&nbsp;Lecturer</a></li>  
                <li><a href="profile.php" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                <li><a href="bot.php" class="hover-underline-animation"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>                
              </ul>
            </div>
        </div>
    </nav> 
    
    <div class="container">
        <div class="row">
            <div class="col-md-2 hidden-sd hidden-xs hidden-md" id="tablet">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav flex-column navbar-left">
                <li><a href="welcome.php" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                <li><a href="announcement.php" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                <li><a href="quiz.php" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                <li><a href="history.php" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                <li><a href="rank.php" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                <li><a href="lecturer.php" class="hover-underline-animation"><span class="glyphicon glyphicon-blackboard" aria-hidden="true"></span>&nbsp;Lecturer</a></li>  
                <li><a href="profile.php" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                <li><a href="bot.php" class="hover-underline-animation"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>                
                </ul>
            </div>
            </div>
    
<div class="col-md-10">
<span class="title1"><h1 style="padding:10px;"><center>Join Quiz</center></h1></span>

<?php
    $result3 = mysqli_query($con, "SELECT * FROM subject") or die('Error');
    while ($row3 = mysqli_fetch_array($result3)) {
        $quiz_subject = $row3['subject'];

        // Loop to retrieve quizzes
        $result = mysqli_query($con, "SELECT * FROM quiz WHERE quiz_subject='$quiz_subject' ORDER BY date DESC LIMIT 8") or die('Error');
        $numRows = mysqli_num_rows($result);

        if($numRows>=1){

            echo "<br/><h3 style='padding-bottom:20px; padding-left: 10px; padding-right:10px;'>Quiz Subject : <span style='color: #0087ca;'>$quiz_subject</span>";
            echo"<a href='quiz_category.php?q=subject&subject=$quiz_subject' class='btn btnStyle mobilebtn' style='float:right;'>
                <span class='glyphicon glyphicon-plus' aria-hidden='true'></span>
                &nbsp;<span class='title1'><b>View All</b></span>
                </a></h3>";    

        while ($row = mysqli_fetch_array($result)) {

            if( $numRows >= 1){
            $quiz_id = $row['quiz_id'];
            $quiz_title = $row['quiz_title'];
            $correct = $row['correct'];
            $wrong = $row['wrong'];
            $total_question = $row['total_question'];
            $diff_level = $row['diff_level'];
            $attempt = $row['attempt'];
            $quiz_subject = $row['quiz_subject'];
            $quiz_visibility = $row['quiz_visibility'];
            $quiz_password = $row['quiz_password'];
            $quiz_image = $row['quiz_image'];
            $question = $row['question'];
            $lecturer_name = $row['lecturer_name'];

            $total_mark = $total_question*$correct;       
        ?>

            <div class="row">

            <div class="column">
                <div class="card">
                    <img src="../image/<?php echo $quiz_image;?>" class="fixed-image">
                    <p><small><i><?php echo $quiz_visibility;?> Quiz</i></small></p>
                    <h2><?php echo $quiz_title; ?></h2>
                    <p>No of questions : <?php echo $total_question;?> questions</p>
                    <p>Total marks : <?php echo $total_mark;?> marks</p>

                    <center><button class="btn btnStyle open-popup" data-target="<?php echo $quiz_title;?>">Join Quiz</button></center>

                    <?php 
                          $result2 = mysqli_query($con, "SELECT * FROM history WHERE user_id='$id' AND quiz_id='$quiz_id'") or die('Error');
                          $rowCount = mysqli_num_rows($result2);                 
                    ?>

                     <!-- Add a unique dialog box for Card 1 -->
                    <div id="<?php echo $quiz_title;?>" class="popup">
                    <div class="popup-content">
                        <span class="close-btn" data-popup="<?php echo $quiz_title;?>">&times;</span>
                        <br/>

                        <img src="../image/<?php echo $quiz_image;?>" class="fixed-image-dialog">

                        <p><small><i><?php echo $quiz_visibility;?> Quiz</i></small></p>
                        <h2><?php echo $quiz_title; ?></h2>
                        <hr/>
                        <p>Subject : <?php echo $quiz_subject; ?></p>
                        <p>Number of question : <?php echo $total_question  ; ?></p>
                        <p>Correct marks : <?php echo $correct; ?> marks</p>
                        <p>Wrong marks : <?php echo $wrong; ?> marks</p>
                        <p>Difficulty level : <?php echo $diff_level; ?> out of 10</p>
                        <p>Number of attempt : <?php echo $attempt; ?> times</p>
                        <p>Prepared by : <?php echo $lecturer_name; ?></p>
                        <br/>

                        <?php

                        if ($rowCount < $attempt){   
                                    
                            if ($quiz_visibility === 'Private') {
                                // If the quiz is private, show a button to start with a password prompt
                                
                            ?>
                            <button class="btn sub3" style="width:100%;"
                            onclick="startPrivateQuiz(<?php echo $quiz_id; ?>, '<?php echo $quiz_password; ?>', <?php echo $total_question; ?>)">
                            <span class="glyphicon glyphicon-new-window" aria-hidden="true"></span>&nbsp;
                            <span class="title1"><b>Start</b></span>
                            </button>

                            <?php
                            } else {
                                // If the quiz is public, show the regular "Start" button
                                echo '<a href="join_quiz.php?q=quiz&quiz_id='.$quiz_id.'&t='.$total_question.'" class="btn sub3">
                                        <span class="glyphicon glyphicon-new-window" aria-hidden="true"></span>&nbsp;
                                        <span class="title1"><b>Start</b></span>
                                    </a>';
                            }
                        }else {
                            echo '<a class="btn sub3" style="color:black; background-color:#bbbbbb; border: 1px solid #bbbbbb">
                                <span class="glyphicon glyphicon-new-window" aria-hidden="true"></span>&nbsp;
                                <span class="title1"><b>Start</b></span>
                            </a>';
                        }
                        ?>
                    
                    </div>
                    </div>
                </div>
                </div>
               
            
                <?php
            }
        }

        echo '</div>';

        }
    }

         echo'</div>';

    ?>

    <script>
// Get all elements with class 'open-popup'
const openButtons = document.querySelectorAll('.open-popup');
const closeButton = document.querySelectorAll('.close-btn');
const popups = document.querySelectorAll('.popup');

// Add click event listeners to open buttons
openButtons.forEach((button) => {
  button.addEventListener('click', (event) => {
    const targetId = event.target.getAttribute('data-target');
    const targetPopup = document.getElementById(targetId);
    targetPopup.style.display = 'block';
  });
});

// Add click event listeners to close buttons
closeButton.forEach((button) => {
  button.addEventListener('click', (event) => {
    const targetPopup = document.getElementById(event.target.getAttribute('data-popup'));
    targetPopup.style.display = 'none';
  });
});

// Add click event listener to close popups when clicking outside the popup
window.addEventListener('click', (event) => {
  popups.forEach((popup) => {
    if (event.target === popup) {
      popup.style.display = 'none';
    }
  });
});

</script>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
 function startPrivateQuiz(quizId, quizPassword, totalQuestion) {
    var enteredPassword = prompt("Please enter the password for this private quiz :");

    if (enteredPassword !== null && enteredPassword === quizPassword) { 
            // Password matches, redirect to the quiz
            window.location.href = 'join_quiz.php?q=quiz&quiz_id=' + quizId + '&t=' + totalQuestion;
    }
    else {
            alert("Private quiz password is incorrect. Please try again.");
        }
    }

</script>

<script>
// Get references to the elements
const profileIcon = document.getElementById('profile-icon');
const profileDialog = document.getElementById('profile-dialog');
const closeDialogBtn = document.getElementById('close-dialog'); // Added close button reference
const viewProfileBtn = document.getElementById('view-profile');

// Add a click event handler to the profile icon
profileIcon.addEventListener('click', () => {
    // Display the dialog box
    profileDialog.style.display = 'block';
});

// Add a click event handler to the "View Profile" button
viewProfileBtn.addEventListener('click', () => {
    window.location.replace('profile.php');
});

// Add a click event handler to the "Close" button
closeDialogBtn.addEventListener('click', () => {
    // Close the dialog
    profileDialog.style.display = 'none';
});

</script>


</body>
</html>