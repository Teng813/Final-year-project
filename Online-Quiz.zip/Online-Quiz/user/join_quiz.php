<?php
    include_once '../database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:../login.php");
    }
    else
    {
        $name = $_SESSION['name'];
        $email = $_SESSION['email'];
        $id = $_SESSION['id'];
        include_once '../database.php';
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Join Quiz | Online Quiz System</title>
    <link  rel="stylesheet" href="../css/bootstrap.min.css"/>
    <link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
    <link rel="stylesheet" href="../css/welcome.css">
    <link  rel="stylesheet" href="../css/font.css">
    <link rel="stylesheet" href="../css/form.css">
    <script src="js/jquery.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
    <script src="js/bootstrap.min.js"  type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>   
</head>

<style>
    /* Style for the timer element */
    #timer {
        font-family: Georgia, serif; 
        font-size: 24px;
        border: 2px solid #0087ca;
        padding: 10px 5px 10px 5px;
        text-align: center;
        border-radius: 10px; 
        width: 100px; 
        margin: 10px auto; 
        background-color: #F5FBFF;
    }

    .fixed-image {
      width: 100%; 
      height: 250px; 
      margin-bottom: 20px;
      object-fit: cover;
    }
</style>


<body>

  <!-- Navigation Menu for Large Screens (Laptops) -->
  <nav class="navbar navbar-default title1 hidden-sd hidden-xs" id="tablet">
    <div class="container-fluid">
        <div class="navbar-header">
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Hidden dialog box -->
        <div id="profile-dialog" class="dialog-box">
            <button id="close-dialog" class="close-button">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
            </button>
            <br/>
            <p>Student ID : <?php echo $id; ?></p>
            <h3><?php echo $name; ?></h3>
            <br/>
            <center><button id="view-profile">View Profile</button></center>
        </div>


<!-- Navigation Menu for Small Screens (Mobile) -->
<nav class="navbar navbar-default title1 hidden-lg">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mobile-menu" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        
        <div class="collapse navbar-collapse" id="mobile-menu">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                <li><a href="" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-blackboard" aria-hidden="true"></span>&nbsp;Lecturer</a></li>  
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>                
              </ul>
            </div>
        </div>
    </nav> 
    
    <div class="container">
        <div class="row">
            <div class="col-md-2 hidden-sd hidden-xs hidden-md" id="tablet">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav flex-column navbar-left">
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                <li><a href="" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-blackboard" aria-hidden="true"></span>&nbsp;Lecturer</a></li>  
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                <li><a href="" class="hover-underline-animation"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>                
                </ul>
            </div>
            </div>

      <div class="col-md-10">
        <div class="row">
          <?php

            if(@$_GET['q']== 'quiz'){

            $quiz_id= $_GET['quiz_id'];

            $total_question=@$_GET['t'];              
            echo '<form action="join_quiz_step2.php?q=quiz&quiz_id='.$quiz_id.'&t='.$total_question.'" method="POST"  class="form-horizontal">';

            echo '<div class="panel">';
            
            $q=mysqli_query($con,"SELECT * FROM quiz WHERE quiz_id='$quiz_id'" );
            while($row=mysqli_fetch_array($q)){
              $quiz_image = $row['quiz_image'];
              $total_question = $row['total_question'];
              $question = $row['question'];
              $quiz_title = $row['quiz_title'];
              $quiz_subject = $row['quiz_subject'];
              $diff_level = $row['diff_level'];
              $attempt = $row['attempt'];
              $correct = $row['correct'];
              $quiz_time = $row['quiz_time'];
            }

            echo "<div class='col-md-12'>";
              echo "<img src='../image/" . $quiz_image . "' class='fixed-image'>
              <center><h1 style='margin-top:-10px;'><b>$quiz_title</b></h1></center>
            </div>";

            echo"<div class='col-md-9'>
              <p style='font-size: 20px;'>Time limit : $quiz_time minutes</p>
              <p style='font-size: 20px;'>Quiz subject : $quiz_subject</p>
              <p style='font-size: 20px;'>Difficulty level : $diff_level out of 10</p>
              <p style='font-size: 20px;'>Number of attempt : $attempt</p>
            </div>";

            echo "<div class='col-md-3'>";
           
            echo "<center><span style='font-size: 20px; font-family: Georgia, serif;'><b>Time remaining : </b></span><center>";
            echo "<div id='timer'>";
            echo $quiz_time . " minutes";
            echo "</div>";
            echo "</div>";

          echo"<div class='col-md-12'>
            <hr/>
          </div>";
            
            // Use the explode function to split the string into an array
              $questionIDs = explode(', ', $question);

            // Create an array to store the values
            $questions = array();

            // Store the questions in an array
            $questions = $questionIDs;
            ?>

          <div class="container">
          <div class="row">
          
          <?php
            for ($a = 1; $a <= $total_question; $a++) {
              // Initialize the $question_title variable
              $question_title = '';
              $current_question_id = $questions[$a - 1];

              $q3 = mysqli_query($con, "SELECT * FROM questions WHERE question_id='$current_question_id'");
              while ($row = mysqli_fetch_array($q3)) {
                  $question_title = $row['question'];
              }
              ?>

              <div class="col-md-12" style="margin-top: 20px; padding: 20px; background-color: #F5FBFF">
                <div class="row">
                  <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-9">
                            <h3 style="color: #0087ca;">Question <?php echo $a; ?>:</h3> 
                            <p style="font-size: 25px; color: #0087ca;"><?php echo $question_title; ?></p>
                        </div>
                        <div class="col-md-3 text-right">
                            <h3 style="color: #0087ca;"><?php echo $correct; ?> marks</h3>
                        </div>
                    </div>
                  </div>
         
                  <?php
                   $options = ['A', 'B', 'C', 'D']; // Define the options as A, B, C, D
                   $optionIndex = 0; // Initialize the option index

                    $q2 = mysqli_query($con, "SELECT * FROM options WHERE question_id='$current_question_id'");                      
                    $shuffledOptions = [];

                      while ($row = mysqli_fetch_array($q2)) {
                          $shuffledOptions[] = $row;
                      }
          
                      // Shuffle the options
                      shuffle($shuffledOptions);
          
                      foreach ($shuffledOptions as $row) {
                          $option = $row['option'];
                          $option_id = $row['option_id'];
        
                        ?>
          
         
                        <div class="col-md-3">
                          <br/><input type="radio" style="font-size: 25px;" name="ans[<?php echo $a; ?>]" value="<?php echo $option; ?> "><span style="font-size: 20px;"> <?php echo $option; ?></span>
                        </div>

                        <?php
                    }

                echo'</div></div>';
            
            }
            ?>
            </div>
        
            <div class="row" style="padding:10px;">
            <div class="col-md-12">
                <div class="form-group">
                    <label class="col-md-12 control-label" for=""></label>
                    <div class="col-md-12"> 
                        <center><a href="quiz.php" class="btn btnStyle" >Quit</a>&nbsp; &nbsp; &nbsp;
                        <button type="submit" name="submit" class="btn btnStyle" id="SubmitButton">
                          <span class="glyphicon glyphicon-lock" aria-hidden="true"></span> Submit
                        </button>
                    </div>
                </div>
            </div>
        </div>

          </div>
      </div>
    </div>
  </div>
</div>

<?php } ?>
       

<script>
  // Set the initial time (in seconds)
  var timeInSeconds = <?php echo $quiz_time * 60; ?>;

  // Function to update the timer
  function updateTimer() {
      var minutes = Math.floor(timeInSeconds / 60);
      var seconds = timeInSeconds % 60;
      
      // Display the time in the "00:00" format
      var timerElement = document.getElementById('timer');
      timerElement.innerHTML = (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;

      // Check if the timer has reached 0
      if (timeInSeconds <= 0) {
          timerElement.innerHTML = "Time's up!";
          document.getElementById('SubmitButton').click();

      } else {
          // Decrease the time by 1 second
          timeInSeconds--;
          setTimeout(updateTimer, 1000); // Update the timer every second
      }
  }

  // Start the timer
  updateTimer();
</script>

<script>
// Get references to the elements
const profileIcon = document.getElementById('profile-icon');
const profileDialog = document.getElementById('profile-dialog');
const closeDialogBtn = document.getElementById('close-dialog'); // Added close button reference
const viewProfileBtn = document.getElementById('view-profile');

// Add a click event handler to the profile icon
profileIcon.addEventListener('click', () => {
    // Display the dialog box
    profileDialog.style.display = 'block';
});

// Add a click event handler to the "View Profile" button
viewProfileBtn.addEventListener('click', () => {
    window.location.replace('profile.php');
});

// Add a click event handler to the "Close" button
closeDialogBtn.addEventListener('click', () => {
    // Close the dialog
    profileDialog.style.display = 'none';
});

</script>



</body>
</html>