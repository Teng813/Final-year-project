<?php
include("../database.php");
session_start();

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $name = $_POST['name'];
    $password = $_POST['password'];
    $c_password = $_POST['c_password'];

    if ($password == $c_password) {
        $confirm_password = $c_password;
    }

    if (
        filter_var($email, FILTER_VALIDATE_EMAIL) &&
        strlen($confirm_password) >= 8 &&
        strlen($confirm_password) <= 10 &&
        preg_match('/^(?=.*[A-Z])(?=.*\d)/', $confirm_password)  // Check for at least one uppercase letter and one number
) {
        
        // Sanitize the input
        $email = mysqli_real_escape_string($con, $email);
        $confirm_password = mysqli_real_escape_string($con, $confirm_password);

        // Check if the user exists
        $query = "SELECT * FROM user WHERE user_email = '$email'";
        $result = mysqli_query($con, $query);

        if (mysqli_num_rows($result) == 1) {
            // User found, update the password
            $updateQuery = "UPDATE `user` SET user_password = '$confirm_password' WHERE user_email = '$email'";

            if (mysqli_query($con, $updateQuery)) {
                echo"<script>alert('Password updated successfully!'); window.location.replace('login.php'); </script>";
            } else {
                echo"<script>alert('Error updating password: " . mysqli_error($con) . "'); </script>";
            }
        } else {
            echo"<script>alert('User not found with the provided email.'); </script>";
        }
    } else {
        echo"<script>alert('Validation failed: Email, password length, uppercase letter, and number requirements not met.'); </script>";
    }
}
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Reset Password | Online Quiz System</title>
		<link  rel="stylesheet" href="../css/bootstrap.min.css"/>
		<link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
		<link rel="stylesheet" href="../css/welcome.css">
		<link  rel="stylesheet" href="../css/font.css">
		<link rel="stylesheet" href="../css/form.css">
		<script src="js/jquery.js" type="text/javascript"></script>
		<script src="js/bootstrap.min.js"  type="text/javascript"></script>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>   
        <style type="text/css">
            body{
                  width: 100%;
                  background: url(../image/book.png) ;
                  background-position: center center;
                  background-repeat: no-repeat;
                  background-attachment: fixed;
                  background-size: cover;
                }
          </style>
	</head>

	<body>
			<div class="container">
			<center><img src="../image/logo.png" alt="Logo" width="100" height="100" style="padding-top:0px;">
			<h1 class="font-effect-shadow-multiple" style="padding-bottom: 15px;">Online Quiz System</h1></center>	
				<div class="box-wrapper">						
					<div class="box box-border">
						<div class="box-body">
						<center><h2>Reset Password</h2><p style="color:red">**Please note that you can only reset your password</p></center><br/>
							<form method="post" action="reset_password.php" enctype="multipart/form-data">
                                <div class="form-group">
									<label>Enter Your Name : </label>
									<input type="text" name="name" class="form-control" required />
								</div>
								<div class="form-group">
									<label>Enter Your Email : </label>
									<input type="email" name="email" class="form-control" required />
								</div>
								<div class="form-group">
									<label>Enter Your New Password : </label>
									<input type="password" name="password" class="form-control" required />
                                </div>

								<div class="form-group">
									<label>Please Confirm Your New Password : </label>
									<input type="password" name="c_password" class="form-control" required />
                                </div>
                                
								<div class="form-group text-right">
									<button class="btn btnStyle btn-block" name="submit">Reset password</button>
								</div>

							</form>
							<a href="../index.php" style="padding-bottom:20px;"><center><span class="text-muted"><< Back to homepage </span></center></a>
						</div>
					</div>
				</div>
			</div>

	</body>
</html>