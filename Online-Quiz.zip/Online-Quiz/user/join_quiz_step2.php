<?php
include_once '../database.php';
session_start();

if (!isset($_SESSION['email'])) {
    header("location:../login.php");
} else {
    $name = $_SESSION['name'];
    $email = $_SESSION['email'];
    $id = $_SESSION['id'];
    include_once '../database.php';
}

// Save answer
if (@$_GET['q'] == 'quiz') {
    $quiz_id = @$_GET['quiz_id'];
    $total_question = @$_GET['t'];
    
    if (isset($_POST['ans'])){
        $user_answers = $_POST['ans'];
    }else{
        $user_answers = '-';
    }

    //score counter, correct answer count, and wrong answer count
    $score = 0;
    $correct_count = 0;
    $wrong_count = 0;
    $this_attempt = 1; // Initialize the attempt to 1

    // get the latest number of attempt by the user 
    $result2 = mysqli_query($con, "SELECT MAX(attempt) AS max_attempt FROM history WHERE quiz_id='$quiz_id' AND user_email='$email'") or die('Error');
    $row2 = mysqli_fetch_array($result2);
    $this_attempt = $row2['max_attempt'] + 1;

    //Retrieve correct and wrong marks
    $q2 = mysqli_query($con, "SELECT * FROM quiz WHERE quiz_id='$quiz_id'");
    while ($row = mysqli_fetch_array($q2)) {
        $correct = $row['correct'];
        $wrong = $row['wrong'];
        $question = $row['question'];
    }

     // Use the explode function to split the string into an array
     $questionIDs = explode(', ', $question);

     // Create an array to store the values
     $questions = array();

     // Store the questions in an array and get current question ID
     $questions = $questionIDs;

     for ($a = 1; $a <= $total_question; $a++) {
        // Get the user's answer for the current question
        if (isset($user_answers[$a])) {
            $user_answer = $user_answers[$a];

        }else{
            // Check if the user's answer is empty and replace it with 'null'
            $user_answer = 'null';
        }    
    
        // Get the corresponding question ID from the array
        $current_question_id = $questions[$a - 1];
    
        $q = mysqli_query($con, "SELECT * FROM questions WHERE question_id='$current_question_id'");
        while ($row = mysqli_fetch_array($q)){
             $answer = $row['answer'];
        }

        // Insert the user's answer into the database
        $q6 = mysqli_query($con, "INSERT INTO answer (ans_id, user_id, ans_user, quiz_id, question_id, answer, attempt) VALUES('', '$id', '$user_answer', '$quiz_id', '$current_question_id', '$answer', '$this_attempt')") or die('Error');

        // Update score based on the answer
        $user_answer_cleaned = trim(strtolower($user_answer)); // Clean and normalize the user's answer
        $answer_cleaned = trim(strtolower($answer)); // Clean and normalize the correct answer

        if ($user_answer_cleaned === $answer_cleaned) {
            $correct_count++;
            $score += $correct;
        } else {
            $wrong_count++;
            $score -= $wrong;
        }

        /*echo $user_answer;
        echo '<br/>';
        echo $answer;
        echo '<br/>';
        echo $correct_count;
        echo '<br/>';
        echo $wrong_count;
        echo '<br/>';
        echo $score;
        echo '<br/>';*/
     
 }
    $q5 = mysqli_query($con, "INSERT INTO history (his_id, user_id, user_name, user_email, quiz_id, score, correct_no, wrong_no, attempt, date) VALUES('', '$id', '$name' , '$email', '$quiz_id', '$score', '$correct_count', '$wrong_count', '$this_attempt', NOW())") or die('Error');
    $q10 = mysqli_query($con, "INSERT INTO archive_history (his_id, user_id, user_name, user_email, quiz_id, score, correct_no, wrong_no, attempt, date) VALUES('', '$id', '$name' , '$email', '$quiz_id', '$score', '$correct_count', '$wrong_count', '$this_attempt', NOW())") or die('Error');

    //for rank
    $q7=mysqli_query($con,"SELECT * FROM rank WHERE user_email='$email' AND quiz_id='$quiz_id'" )or die('Error161');
    $rowcount=mysqli_num_rows($q7);

    if($rowcount == 0)
    {
        $q8 = mysqli_query($con, "INSERT INTO rank (rank_id, user_id, user_email, user_name, score, quiz_id) VALUES('', '$id', '$email', '$name', '$score', '$quiz_id')") or die(mysqli_error($con));
        $q11 = mysqli_query($con, "INSERT INTO archive_rank (rank_id, user_id, user_email, user_name, score, quiz_id) VALUES('', '$id', '$email', '$name', '$score', '$quiz_id')") or die(mysqli_error($con));

    }else{

        while ($row = mysqli_fetch_array($q7)){
            $old_score = $row['score'];
    
            if ($score >= $old_score){
                $q=mysqli_query($con,"UPDATE `rank` SET `score`=$score WHERE user_email= '$email' AND quiz_id='$quiz_id'")or die('Error174');
                $q=mysqli_query($con,"UPDATE `archive_rank` SET `score`=$score WHERE user_email= '$email' AND quiz_id='$quiz_id'")or die('Error174');

            } 
        }
    }

    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Grade Report | Online Quiz System</title>
    <link  rel="stylesheet" href="../css/bootstrap.min.css"/>
    <link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
    <link rel="stylesheet" href="../css/welcome.css">
    <link  rel="stylesheet" href="../css/font.css">
    <link rel="stylesheet" href="../css/form.css">
    <script src="js/jquery.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
    <script src="js/bootstrap.min.js"  type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>   
</head>

<body>
 
  <!-- Navigation Menu for Large Screens (Laptops) -->
  <nav class="navbar navbar-default title1 hidden-sd hidden-xs" id="tablet">
    <div class="container-fluid">
        <div class="navbar-header">
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Hidden dialog box -->
        <div id="profile-dialog" class="dialog-box">
            <button id="close-dialog" class="close-button">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
            </button>
            <br/>
            <p>Student ID : <?php echo $id; ?></p>
            <h3><?php echo $name; ?></h3>
            <br/>
            <center><button id="view-profile">View Profile</button></center>
        </div>


<!-- Navigation Menu for Small Screens (Mobile) -->
<nav class="navbar navbar-default title1 hidden-lg">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mobile-menu" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        
        <div class="collapse navbar-collapse" id="mobile-menu">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
                <li><a href="welcome.php" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                <li><a href="announcement.php" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                <li><a href="quiz.php" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                <li><a href="history.php" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                <li><a href="rank.php" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                <li><a href="profile.php" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                <li><a href="bot.php" class="hover-underline-animation"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>                
              </ul>
            </div>
        </div>
    </nav> 
    
    <div class="container">
        <div class="row">
            <div class="col-md-2 hidden-sd hidden-xs hidden-md" id="tablet">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav flex-column navbar-left">
                <li><a href="welcome.php" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                <li><a href="announcement.php" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                <li><a href="quiz.php" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                <li><a href="history.php" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                <li><a href="rank.php" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                <li><a href="profile.php" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                <li><a href="bot.php" class="hover-underline-animation"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>                
                </ul>
            </div>
            </div>

    <div class="col-md-10">

    <div class="panel">
    <center><h1 class="title" style="color:#660033">Result</h1></center>
    <br /><table class="table table-striped title1" style="font-size:20px;font-weight:1000; font-family: Georgia, serif">

    <?php
    echo '<tr style="color:#66CCFF">
        <td>Total Questions</td>
        <td>'.$total_question.'</td>
    </tr>
        
    <tr style="color:#99cc32">
        <td>Correct Answer&nbsp;<span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span></td>
        <td>'.$correct_count.'</td>
    </tr> 

    <tr style="color:red">
        <td>Wrong Answer&nbsp;<span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span></td>
        <td>'.$wrong_count.'</td>
    </tr>
        
    <tr style="color:#66CCFF">
        <td>Score&nbsp;<span class="glyphicon glyphicon-star" aria-hidden="true"></span></td>
        <td>'.$score.'</td>
    </tr>';
    
    echo '</table></div>';

    $quiz_id= $_GET['quiz_id'];
    $total_question=@$_GET['t'];
                
    echo '<div class="panel">';
    
    $q=mysqli_query($con,"SELECT * FROM quiz WHERE quiz_id='$quiz_id'" );
    while($row=mysqli_fetch_array($q)){
        $total_question = $row['total_question'];
        $question = $row['question'];
        $quiz_title = $row['quiz_title'];
        $quiz_subject = $row['quiz_subject'];
        $diff_level = $row['diff_level'];
        $attempt = $row['attempt'];
        $correct = $row['correct'];
        $wrong = $row['wrong']; 
        
        echo "<h1 style='color: #660033; text-align:center;' >Grade Report</h1>
        <br/><h2 style='color: #0087ca;'>$quiz_title</h2>
        <p style='font-size: 20px;'>Quiz subject : $quiz_subject</p>
        <p style='font-size: 20px;'>Difficulty level : $diff_level</p>
        <p style='font-size: 20px;'>Number of attempt : $attempt</p>
        <hr/>";
        
        // Use the explode function to split the string into an array
        $questionIDs = explode(', ', $question);

        // Create an array to store the values
        $questions = array();

        // Store the questions in an array
        $questions = $questionIDs;
    }

    ?>

    <div class="container">
    <div class="row">
    
    <?php
        for ($a = 1; $a <= $total_question; $a++) {
        // Initialize the $question_title variable
        $question_title = '';
        $current_question_id = $questions[$a - 1];

        $q3 = mysqli_query($con, "SELECT * FROM questions WHERE question_id='$current_question_id'");
        while ($row = mysqli_fetch_array($q3)) {
            $question_title = $row['question'];
        }
        ?>

        <div class="col-md-12" style="margin-top: 20px; padding: 20px; background-color: #F5FBFF">
            <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-9">
                        <h3 style="color: #0087ca;">Question <?php echo $a; ?>:</h3> 
                        <p style="font-size: 25px; color: #0087ca;"><?php echo $question_title; ?></p>                        
                        <br/><p style="font-size: 20px; font-weight: 800; color: red;">Correct answer : </p>
                    </div>

                    <?php 
                        $q3 = mysqli_query($con, "SELECT * FROM answer WHERE question_id='$current_question_id' AND user_id='$id' AND attempt='$this_attempt'");
                        while ($row = mysqli_fetch_array($q3)) {
                            $correct_answer = $row['answer'];
                            $user_answer = $row['ans_user'];
                        }
                             // Update score based on the answer
                            $user_answer_cleaned = trim(strtolower($user_answer)); // Clean and normalize the user's answer
                            $answer_cleaned = trim(strtolower($correct_answer)); // Clean and normalize the correct answer

                            if ($answer_cleaned == $user_answer_cleaned) {
                                echo'<div class="col-md-3 text-right">
                                    <h3 style="color: red;">'.$correct.' marks</h3>
                                </div>';
                            }else{
                                echo'<div class="col-md-3 text-right">
                                    <h3 style="color:#808080 ;">- '.$wrong.' marks</h3>
                                </div>';
                            }
                       
                    ?>   
                                
                </div>
            </div>

            <?php
                $q2 = mysqli_query($con, "SELECT * FROM options WHERE question_id='$current_question_id'");
                while ($row = mysqli_fetch_array($q2)) {
                    $option = $row['option'];
                    $option_id = $row['option_id'];

                    $q3 = mysqli_query($con, "SELECT * FROM questions WHERE question_id='$current_question_id'");
                    while ($row = mysqli_fetch_array($q3)) {
                        $correct_answer = $row['answer'];

                        if ($option == $correct_answer) {
                            
                            echo '<div class="col-md-3">
                                    <input type="radio" style="font-size: 25px;" name="ans[' . $a . ']" value="' . $option . '" checked disabled><span style="font-size: 18px; color:red;"> ' . $option . '</span>
                                </div>';

                        } else {

                            echo '<div class="col-md-3">
                                    <input type="radio" style="font-size: 25px;" name="ans[' . $a . ']" value="' . $option . '" disabled><span style="font-size: 18px;"> ' . $option . '</span>
                                </div>';

                        }
                    }
                }

                //for displaying user's answer          
                echo'<div class="col-md-12"> 
                    <br/><br/><p style="font-size: 20px; font-weight: 800;">Your answer :  '.$user_answer.'</p>
                </div>';

                echo'</div></div>';
        }
    ?>
    
    <?php

        $q4=mysqli_query($con,"SELECT * FROM history WHERE quiz_id='$quiz_id' AND attempt='$this_attempt' AND user_id='$id'" );
        while($row=mysqli_fetch_array($q4)){
            $his_id = $row['his_id'];
            $user_id = $row['user_id'];
            $user_email = $row['user_email'];
            $quiz_id = $row['quiz_id'];
            $score = $row['score'];
            $correct_no = $row['correct_no'];
            $wrong_no = $row['wrong_no'];
            $attempt = $row['attempt'];
            $date = $row['date'];

            $q9=mysqli_query($con,"SELECT user_name FROM user WHERE user_email='$user_email'" );
            while($row=mysqli_fetch_array($q9)){
                $user_name = $row['user_name'];

    ?>

<form action="grade_report.php" method="POST">

    <input type="hidden" name="his_id" value="<?php echo $his_id; ?>">
    <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
    <input type="hidden" name="user_email" value="<?php echo $user_email; ?>">
    <input type="hidden" name="quiz_id" value="<?php echo $quiz_id; ?>">
    <input type="hidden" name="score" value="<?php echo $score; ?>">
    <input type="hidden" name="correct_no" value="<?php echo $correct_no; ?>">
    <input type="hidden" name="wrong_no" value="<?php echo $wrong_no; ?>">
    <input type="hidden" name="attempt" value="<?php echo $attempt; ?>">
    <input type="hidden" name="date" value="<?php echo $date; ?>">
    <input type="hidden" name="user_name" value="<?php echo $user_name; ?>">
    <input type="hidden" name="quiz_title" value="<?php echo $quiz_title; ?>">
    <input type="hidden" name="quiz_subject" value="<?php echo $quiz_subject; ?>">
    <input type="hidden" name="diff_level" value="<?php echo $diff_level; ?>">
    <?php

            }
        }
    ?>

    <div class="col-md-12" style="padding-top:20px;"> 
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-3">
                <a href="quiz.php" class="btn btnStyle" style="text-align: center;"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Back to quiz page</a>
            </div>
            <div class="col-md-3">
                <button type='submit' name='submit'class='btn btnStyle'><span class='glyphicon glyphicon-file'></span> Download PDF</button>
            </div>
    </div>
    </form>

<script>
// Get references to the elements
const profileIcon = document.getElementById('profile-icon');
const profileDialog = document.getElementById('profile-dialog');
const closeDialogBtn = document.getElementById('close-dialog'); // Added close button reference
const viewProfileBtn = document.getElementById('view-profile');

// Add a click event handler to the profile icon
profileIcon.addEventListener('click', () => {
    // Display the dialog box
    profileDialog.style.display = 'block';
});

// Add a click event handler to the "View Profile" button
viewProfileBtn.addEventListener('click', () => {
    window.location.replace('profile.php');
});

// Add a click event handler to the "Close" button
closeDialogBtn.addEventListener('click', () => {
    // Close the dialog
    profileDialog.style.display = 'none';
});

</script>
                
        
</body>
</html>