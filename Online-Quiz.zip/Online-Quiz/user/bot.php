<?php
    include_once '../database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:login.php");
    }
    else
    {
        $name = $_SESSION["name"];
        $email = $_SESSION['email'];
        $id = $_SESSION['id'];
        include_once '../database.php';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chatbot | Online Quiz System</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link  rel="stylesheet" href="../css/bootstrap.min.css"/>
    <link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
    <link rel="stylesheet" href="../css/welcome.css">
    <link  rel="stylesheet" href="./css/font.css">
    <link rel="stylesheet" href="../css/form.css">
    <script src="js/jquery.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
    <script src="js/bootstrap.min.js"  type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> 
</head>
<body>

  <!-- Navigation Menu for Large Screens (Laptops) -->
  <nav class="navbar navbar-default title1 hidden-sd hidden-xs" id="tablet">
    <div class="container-fluid">
        <div class="navbar-header">
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Hidden dialog box -->
        <div id="profile-dialog" class="dialog-box">
            <button id="close-dialog" class="close-button">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
            </button>
            <br/>
            <p>Student ID : <?php echo $id; ?></p>
            <h3><?php echo $name; ?></h3>
            <br/>
            <center><button id="view-profile">View Profile</button></center>
        </div>


<!-- Navigation Menu for Small Screens (Mobile) -->
<nav class="navbar navbar-default title1 hidden-lg">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mobile-menu" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        
        <div class="collapse navbar-collapse" id="mobile-menu">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
                <li><a href="welcome.php" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                <li><a href="announcement.php" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                <li><a href="quiz.php" class="hover-underline-animation"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                <li><a href="history.php" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                <li><a href="lecturer.php" class="hover-underline-animation"><span class="glyphicon glyphicon-blackboard" aria-hidden="true"></span>&nbsp;Lecturer</a></li>  
                <li><a href="rank.php" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                <li><a href="profile.php" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                <li><a href="bot.php" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>                
              </ul>
            </div>
        </div>
    </nav> 
    
    <div class="container">
        <div class="row">
            <div class="col-md-2 hidden-sd hidden-xs hidden-md" id="tablet">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav flex-column navbar-left">
                <li><a href="welcome.php" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                <li><a href="announcement.php" class="hover-underline-animation"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span>&nbsp;Announcement</a></li>
                <li><a href="quiz.php" class="hover-underline-animation"><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                <li><a href="history.php" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                <li><a href="rank.php" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                <li><a href="lecturer.php" class="hover-underline-animation"><span class="glyphicon glyphicon-blackboard" aria-hidden="true"></span>&nbsp;Lecturer</a></li>  
                <li><a href="profile.php" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                <li><a href="bot.php" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;Chat</a></li>                
                </ul>
            </div>
            </div>
    
<div class="col-md-10">

    <div class="wrapper">
        <div class="title">Online Chatbot</div>
        <div class="form">
            <div class="bot-inbox inbox">
                <div class="icon">
                    <img src="../image/logo.png" width="40px" height="40px">
                </div>
                <div class="msg-header">
                    <p>Hi, welcome to online quiz system. how can I help you?<br/>Reply 1 for Frequently Asked Question (FAQ).<br/>Reply 2 for sending us a feedback.</p>
                </div>
            </div>
        </div>
        <div class="typing-field">
            <div class="input-data">
                <input id="data" type="text" placeholder="Type something here.." required>
                <button id="send-btn">Send</button>
            </div>
        </div>
    </div>
</div>
</div>

    <script>
        $(document).ready(function(){
            $("#send-btn").on("click", function(){
                $value = $("#data").val();
                $msg = '<div class="user-inbox inbox"><div class="msg-header"><p>'+ $value +'</p></div></div>';
                $(".form").append($msg);
                $("#data").val('');
                
                // start ajax code
                $.ajax({
                    url: 'message.php',
                    type: 'POST',
                    data: 'text='+$value,
                    success: function(result){
                        $replay = '<div class="bot-inbox inbox"><div class="icon"><img src="../image/logo.png" width="40px" height="40px"></div><div class="msg-header"><p>'+ result +'</p></div></div>';
                        $(".form").append($replay);
                        // when chat goes down the scroll bar automatically comes to the bottom
                        $(".form").scrollTop($(".form")[0].scrollHeight);
                    }
                });
            });
        });
    </script>
    
    <script>
    // Get references to the elements
    const profileIcon = document.getElementById('profile-icon');
    const profileDialog = document.getElementById('profile-dialog');
    const closeDialogBtn = document.getElementById('close-dialog'); // Added close button reference
    const viewProfileBtn = document.getElementById('view-profile');

    // Add a click event handler to the profile icon
    profileIcon.addEventListener('click', () => {
        // Display the dialog box
        profileDialog.style.display = 'block';
    });

    // Add a click event handler to the "View Profile" button
    viewProfileBtn.addEventListener('click', () => {
        window.location.replace('profile.php');
    });

    // Add a click event handler to the "Close" button
    closeDialogBtn.addEventListener('click', () => {
        // Close the dialog
        profileDialog.style.display = 'none';
    });

    </script>

</body>
</html>