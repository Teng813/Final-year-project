<?php
include_once '../database.php';
session_start();
if (!isset($_SESSION['email'])) {
    header("location:login.php");
    exit; // Exit the script if the user is not logged in.
}

$name = $_SESSION["name"];
$email = $_SESSION['email'];
$id = $_SESSION['id'];

$number = $_POST['number'];
$quiz_subject = $_POST['quiz_subject'];

for ($i = 1; $i <= $number; $i++) {
    // Generate a new question_id for each question
    $query = "SHOW TABLE STATUS LIKE 'questions'";
    $result = mysqli_query($con, $query);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $autoIncrement = $row['Auto_increment'];
        $question_id = $autoIncrement;
    }

    // Question text
    $question = $_POST["question_" . $question_id];

    // Retrieve the options
    $a = $_POST[$question_id . '_a'];
    $b = $_POST[$question_id . '_b'];
    $c = $_POST[$question_id . '_c'];
    $d = $_POST[$question_id . '_d'];

    // Calculate the number of non-empty choices in a question
    $number_of_choice = 0;

    // Check and replace null values
    if (empty($a)) {
        $a = 'N/A';
    }else{
        $number_of_choice++;
    }
    
    if (empty($b)) {
        $b = 'N/A';
    }else{
        $number_of_choice++;
    }
    
    if (empty($c)) {
        $c = 'N/A';
    }else{
        $number_of_choice++;
    }
    
    if (empty($d)) {
        $d = 'N/A';
    }else{
        $number_of_choice++;
    }
    
    // Correct answer ID for this question
    $selectedOption = $_POST["correct_ans_" . $question_id];

    switch ($selectedOption) {
        case $question_id . '_a':
            $correctAnswerText = $a;
            break;
        case $question_id . '_b':
            $correctAnswerText = $b;
            break;
        case $question_id . '_c':
            $correctAnswerText = $c;
            break;
        case $question_id . '_d':
            $correctAnswerText = $d;
            break;
        default:
            $correctAnswerText = "No answer selected";
    }

        $q3 = mysqli_query($con, "INSERT INTO questions (question_id, question, choice, answer, subject, lecturer_name) VALUES ('$question_id', '$question', '$number_of_choice', '$correctAnswerText', '$quiz_subject','$name')");
        
        $qa = mysqli_query($con, "INSERT INTO options (question_id, `option`, option_id) VALUES ('$question_id', '$a', '{$question_id}a')");
        $qb = mysqli_query($con, "INSERT INTO options (question_id, `option`, option_id) VALUES ('$question_id', '$b', '{$question_id}b')");
        $qc = mysqli_query($con, "INSERT INTO options (question_id, `option`, option_id) VALUES ('$question_id', '$c', '{$question_id}c')");
        $qd = mysqli_query($con, "INSERT INTO options (question_id, `option`, option_id) VALUES ('$question_id', '$d', '{$question_id}d')");

        $question_id++;
    }
    echo"<script>alert('You have successfully added the question!'); window.location.replace('question_bank.php'); </script>";			

?>
