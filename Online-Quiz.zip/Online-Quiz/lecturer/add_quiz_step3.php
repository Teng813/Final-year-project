<?php

include_once '../database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:login.php");
    }
    else
    {
        $name = $_SESSION["name"];
        $email = $_SESSION['email'];
        $id = $_SESSION['id'];
        include_once '../database.php';
    }

//data from step 1
$quiz_title = $_SESSION['quiz_title'];
$quiz_subject = $_SESSION['quiz_subject'];
$correct = $_SESSION['correct'];
$wrong = $_SESSION['wrong'];
$diff_level = $_SESSION['diff_level'];
$attempt = $_SESSION['attempt'];
$quiz_visibility = $_SESSION['quiz_visibility'];
$quiz_time = $_SESSION['quiz_time'];
$quiz_password = $_SESSION['quiz_password'];
$quiz_image = $_SESSION['quiz_image'];


if (isset($_POST['selected_rows']) && is_array($_POST['selected_rows'])) {
    // Retrieve the selected question IDs
    $selectedQuestionIDs = $_POST['selected_rows'];

    $total_question = count($selectedQuestionIDs);

    // Use implode to create a comma-separated list
    $question = implode(', ', $selectedQuestionIDs);
}

//for quiz_id
$query2 = "SHOW TABLE STATUS LIKE 'quiz'";
$result = mysqli_query($con, $query2);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    $autoIncrement = $row['Auto_increment'];
    $quiz_id = $autoIncrement;
}

$query = mysqli_query($con, "INSERT INTO quiz (quiz_id, quiz_title, question, correct, wrong, total_question, date, diff_level, attempt, quiz_subject, quiz_visibility , quiz_time , quiz_password, lecturer_name, quiz_image) VALUES ('$quiz_id', '$quiz_title', '$question', '$correct', '$wrong', '$total_question', NOW(), '$diff_level', '$attempt', '$quiz_subject', '$quiz_visibility' , '$quiz_time' , '$quiz_password' , '$name','$quiz_image')");

echo"<script>alert('You have successfully added a new quiz!'); window.location.replace('quizzes.php'); </script>";			
?>

