<?php

include_once '../database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:login.php");
    }
    else
    {
        $name = $_SESSION["name"];
        $email = $_SESSION['email'];
        $id = $_SESSION['id'];
        include_once '../database.php';
    }

//data from step 1
$quiz_id = $_SESSION['quiz_id'];
$quiz_title = $_SESSION['quiz_title'];
$quiz_subject = $_SESSION['quiz_subject'];
$correct = $_SESSION['correct'];
$wrong = $_SESSION['wrong'];
$diff_level = $_SESSION['diff_level'];
$attempt = $_SESSION['attempt'];
$quiz_visibility = $_SESSION['quiz_visibility'];
$quiz_time = $_SESSION['quiz_time'];
$quiz_password = $_SESSION['quiz_password'];
$quiz_image = $_SESSION['quiz_image'];

if (isset($_POST['selected_rows']) && is_array($_POST['selected_rows'])) {
    // Retrieve the selected question IDs
    $selectedQuestionIDs = $_POST['selected_rows'];

    $total_question = count($selectedQuestionIDs);

    // Use implode to create a comma-separated list
    $question = implode(', ', $selectedQuestionIDs);
}


$query = "SELECT * FROM `quiz` WHERE `quiz_id` = '$quiz_id'";
        $result = mysqli_query($con, $query);
 
        while ($row = mysqli_fetch_array($result)) {
            $updateQuery = "UPDATE `quiz` SET `quiz_title` = '$quiz_title', `question` = '$question', `correct` = '$correct', `wrong` = '$wrong', `total_question` = '$total_question', `diff_level` = '$diff_level', `attempt` = '$attempt', `quiz_time` = '$quiz_time' , `quiz_image` = '$quiz_image' WHERE `quiz_id` = '$quiz_id'";
 
             if (mysqli_query($con, $updateQuery)) {
                 echo"<script>alert('Quiz updated successfully!'); window.location.replace('quizzes.php'); </script>";
             } else {
                 echo"<script>alert('Error updating quiz: " . mysqli_error($con) . "'); window.location.replace('quizzes.php');</script>";
             }
         }
?>