<?php
    include_once '../database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:login.php");
    }
    else
    {
        $name = $_SESSION["name"];
        $email = $_SESSION['email'];
        $id = $_SESSION['id'];
        include_once '../database.php';
    }

    if (isset($_POST['submit'])){
        $lecturer_id=$id;
        $profile_image =  $_POST['profile_image'];

        $updateQuery = "UPDATE `lecturer` SET `lecturer_image` = '$profile_image' WHERE `lecturer_id` = '$id'";
 
        if (mysqli_query($con, $updateQuery)) {
            echo"<script>alert('Profile updated successfully!'); window.location.replace('lecturer_profile.php'); </script>";
        } else {
            echo"<script>alert('Error updating profile: " . mysqli_error($con) . "'); window.location.replace('lecturer_profile.php');</script>";
        }

    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Profile | Online Quiz System</title>
    <link  rel="stylesheet" href="../css/bootstrap.min.css"/>
    <link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
    <link rel="stylesheet" href="../css/welcome.css">
    <link  rel="stylesheet" href="../css/font.css">
    <link rel="stylesheet" href="../css/form.css">
    <script src="js/jquery.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js"  type="text/javascript"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>   
    
    <style>
        .card {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            padding: 20px;
            text-align: left;
            background-color: #f1f1f1;
            font-size: 20px;
        }
    </style>

</head>

<body>
  <!-- Navigation Menu for Large Screens (Laptops) -->
  <nav class="navbar navbar-default title1 hidden-sd hidden-xs" id="tablet">
    <div class="container-fluid">
        <div class="navbar-header">
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Hidden dialog box -->
        <div id="profile-dialog" class="dialog-box">
            <button id="close-dialog" class="close-button">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
            </button>
            <br/>
            <p>Lecturer ID : <?php echo $id; ?></p>
            <h3><?php echo $name; ?></h3>
            <br/>
            <center><button id="view-profile">View Profile</button></center>
        </div>


<!-- Navigation Menu for Small Screens (Mobile) -->
<nav class="navbar navbar-default title1 hidden-lg">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mobile-menu" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        
        <div class="collapse navbar-collapse" id="mobile-menu">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Student</a></li>
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
              <li><a href="#" class="hover-underline-animation" ><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span>&nbsp;Remove Quiz</a></li>
              <li><a href="#" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
              </ul>
            </div>
        </div>
    </nav> 
    
    <div class="container">
        <div class="row">
            <div class="col-md-2 hidden-sd hidden-xs hidden-md" id="tablet">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav flex-column navbar-left">
                <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Student</a></li>
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
              <li><a href="#" class="hover-underline-animation" ><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span>&nbsp;Remove Quiz</a></li>
              <li><a href="#" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                </ul>
            </div>
            </div>

    <form class="title1" name="form" action="edit_profile.php?id=<?php echo $id;?>"  method="POST">

    <div class="col-md-10">
    <span class="title1"><h1 style="padding:10px;"><center>Edit Profile</center></h1></span>

    <?php 
        $result = mysqli_query($con,"SELECT * FROM lecturer WHERE lecturer_id='$id'") or die('Error');
        
        while($row = mysqli_fetch_array($result)) {
            $lecturer_image = $row['lecturer_image'];
            $lecturer_id = $row['lecturer_id'];
            $lecturer_email = $row['lecturer_email'];
            $lecturer_name = $row['lecturer_name'];

            ?>

            <div class="row"> 
                <div class="col-md-4"></div>
                <div class="col-md-4">
                    <div class="card">
                        <center><img src="../image/<?php echo $lecturer_image; ?>" alt="Profile Picture" width="150" height="150" style="margin-top:30px; margin-bottom:15px;"></center>
                        <center><p><small>Please upload a profile picture</small></p>
                        <input type="file" id="fileName" name="profile_image" class="btn btnStyle"  style="padding-left:10px;padding-right:10px;" accept=".jpg,.jpeg,.png,.gif" onchange="validateFileType(this)" />
                        <br/>
                        <p><i class="fas fa-user"></i><?php echo ' ID : '; 
                        echo $lecturer_id; ?></p>
                        <p><?php echo 'Name : ';
                        echo $lecturer_name; ?>
                        <p><?php echo 'Email : ';
                        echo $lecturer_email; ?>
                    </center></div>
                </div><div class="col-md-4"></div>
            </div>

            <div class="row" style="padding:10px;">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for=""></label>
                            <div class="col-md-12"> 
                                <center><a href="lecturer_profile.php" class="btn btnStyle" >Cancel</a>&nbsp; &nbsp; &nbsp;<input type="submit" value="Submit" name="submit" class="btn btnStyle"/></center>
                            </div>
                        </div>
                    </div>
                </div>

        <?php 
        }
        
    ?>
    
    </div>

<script type="text/javascript">
  function validateFileType(input) {
    var fileName = input.value;
    var idxDot = fileName.lastIndexOf(".") + 1;
    var extFile = fileName.substr(idxDot, fileName.length).toLowerCase();

    if (extFile == "jpg" || extFile == "jpeg" || extFile == "png" || extFile == "gif") {
      // File is valid. You can add further processing here.
    } else {
      alert("Only jpg, jpeg, png, and gif files are allowed!");

      // Delay clearing the input for a few milliseconds
      setTimeout(function() {
        input.value = ''; // Clear the input field
      }, 100);

      // Note: You can adjust the delay (100 milliseconds in this example) as needed.
    }
  }
</script>


<script>
// Get references to the elements
const profileIcon = document.getElementById('profile-icon');
const profileDialog = document.getElementById('profile-dialog');
const closeDialogBtn = document.getElementById('close-dialog'); // Added close button reference
const viewProfileBtn = document.getElementById('view-profile');

// Add a click event handler to the profile icon
profileIcon.addEventListener('click', () => {
    // Display the dialog box
    profileDialog.style.display = 'block';
});

// Add a click event handler to the "View Profile" button
viewProfileBtn.addEventListener('click', () => {
    window.location.replace('lecturer_profile.php');
});

// Add a click event handler to the "Close" button
closeDialogBtn.addEventListener('click', () => {
    // Close the dialog
    profileDialog.style.display = 'none';
});

</script>

</body>
</html>