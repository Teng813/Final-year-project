<?php
    include_once '../database.php';
    session_start();
    if (!(isset($_SESSION['email']))) {
        header("location:login.php");
    } else {
        $name = $_SESSION["name"];
        $email = $_SESSION['email'];
        $id = $_SESSION['id'];
    }
     
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Question | Online Quiz System</title>
    <link  rel="stylesheet" href="../css/bootstrap.min.css"/>   
    <link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
    <link rel="stylesheet" href="../css/welcome.css">
    <link  rel="stylesheet" href="../css/font.css">
    <link rel="stylesheet" href="../css/form.css">
    <script src="js/jquery.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js"  type="text/javascript"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>

<body>

  <!-- Navigation Menu for Large Screens (Laptops) -->
  <nav class="navbar navbar-default title1 hidden-sd hidden-xs" id="tablet">
    <div class="container-fluid">
        <div class="navbar-header">
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Hidden dialog box -->
        <div id="profile-dialog" class="dialog-box">
            <button id="close-dialog" class="close-button">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
            </button>
            <br/>
            <p>Lecturer ID : <?php echo $id; ?></p>
            <h3><?php echo $name; ?></h3>
            <br/>
            <center><button id="view-profile">View Profile</button></center>
        </div>


<!-- Navigation Menu for Small Screens (Mobile) -->
<nav class="navbar navbar-default title1 hidden-lg">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mobile-menu" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        
        <div class="collapse navbar-collapse" id="mobile-menu">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                  <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Student</a></li>
                  <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                  <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                  <li><a href="#" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
                  <li><a href="#" class="hover-underline-animation" ><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
                  <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                  <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span>&nbsp;Remove Quiz</a></li>
                  <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                    
              </ul>
            </div>
        </div>
    </nav> 
    
    <div class="container">
        <div class="row">
            <div class="col-md-2 hidden-sd hidden-xs hidden-md" id="tablet">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav flex-column navbar-left">
                <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Student</a></li>
                  <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                  <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                  <li><a href="#" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
                  <li><a href="#" class="hover-underline-animation" ><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
                  <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                  <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span>&nbsp;Remove Quiz</a></li>
                  <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                </ul>
            </div>
            </div>

    <?php
        $number = $_POST['number'];
        $question_added = $number;

        // Query to get the latest question ID
        $query = "SHOW TABLE STATUS LIKE 'questions'";
        $result = mysqli_query($con, $query);

        if ($result) {
            $row = mysqli_fetch_assoc($result);
            $autoIncrement = $row['Auto_increment'];
            $question_id = $autoIncrement;
        }
        ?>

        <div class="col-md-10">
            <div class="row" id="myDiv" >
            <span class="title1"><h1 style="padding:10px;"><center>Create new question/questions</center></h1></span>
            <div class="col-md-3"></div><div class="col-md-6">   
            <form class="form-horizontal title1" name="form" action="add_question_step3.php" method="POST" id="quiz-form"> 

                <div class="form-group">
                        <label class="col-md-12 control-label" for="number">Enter number of questions : </label>  
                        <div class="col-md-12">
                            <input id="number" name="number" value="<?php echo isset($_POST['number']) ? $_POST['number'] : ''; ?>" class="form-control input-md" type="text" readonly>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-12 control-label" for="quiz_subject">Enter subject of the question/questions :</label>  
                        <div class="col-md-12">
                            <input id="quiz_subject" name="quiz_subject" value="<?php echo isset($_POST['quiz_subject']) ? $_POST['quiz_subject'] : ''; ?>" class="form-control input-md" type="text" readonly>
                        </div>
                    </div><br/>

        <?php
        //for every question loop
        for($i=1; $i<=$number; $i++)
        {           
            // Generate a new question_id for each question
            $question_id = $autoIncrement + $i - 1;

            ?>                

            <div class="form-group">
                <label class="col-md-12 control-label" for="question_id">Question ID :</label>
                <div class="col-md-12">
                    <input id="question_id" name="question_id" value="<?php echo $question_id; ?>" class="form-control input-md" type="text" readonly>
                </div>
            </div>

                <!-- start to enter the questions -->
                <b>Question number&nbsp; <?php echo $i; ?>&nbsp;:</b><br/>
                    <div class="form-group">
                        <label class="col-md-12 control-label" for="question_<?= $question_id ?>">
                            <textarea rows="3" cols="5" name="question_<?= $question_id ?>" placeholder="Please enter the question for question <?php echo $i ?>" class="form-control" required></textarea>
                    </div>

                    <div class="form-group">
                        <label class="col-md-12 control-label" for="<?= $question_id ?>_a"></label>
                        <div class="col-md-12">
                            <input id="<?= $question_id ?>_a" name="<?= $question_id ?>_a" placeholder="Enter option a" class="form-control input-md" type="text" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-12 control-label" for="<?= $question_id ?>_b"></label>
                        <div class="col-md-12">
                            <input id="<?= $question_id ?>_b" name="<?= $question_id ?>_b" placeholder="Enter option b" class="form-control input-md" type="text" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-12 control-label" for="<?= $question_id ?>_c"></label>
                        <div class="col-md-12">
                            <input id="<?= $question_id ?>_c" name="<?= $question_id ?>_c" placeholder="Enter option c" class="form-control input-md" type="text" >                       
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-12 control-label" for="<?= $question_id ?>_d"></label>
                        <div class="col-md-12">
                            <input id="<?= $question_id ?>_d" name="<?= $question_id ?>_d" placeholder="Enter option d" class="form-control input-md" type="text"  >                                          
                        </div>
                    </div>

                    <br/><b>Correct answer :</b>
                        <div class="form-group">
                            <div class="col-md-12">
                                <select id="correct_ans_<?= $question_id ?>" name="correct_ans_<?= $question_id ?>" class="form-control input-md" required>
                                    <option value="#" disabled selected>Select answer for question <?= $i ?></option>
                                    <option value="<?= $question_id ?>_a">Option a</option>
                                    <option value="<?= $question_id ?>_b">Option b</option>
                                    <option value="<?= $question_id ?>_c">Option c</option>
                                    <option value="<?= $question_id ?>_d">Option d</option>
                                </select>
                            </div>
                        </div>

        <?php 
            $question_id++;
            } 
        ?>

                <div class="row" style="padding:10px;">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for=""></label>
                            <div class="col-md-12"> 
                                <center><a href="question_bank.php" class="btn btnStyle" >Cancel</a>&nbsp; &nbsp; &nbsp;<input type="submit" value="Done" name="submit" class="btn btnStyle"/></center>
                            </div>
                        </div>
                    </div>
                </div>
           

            </fieldset>
            </form>
        </div>
        
        </div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('quiz-form');

    form.addEventListener('submit', function (event) {
        // Get all the select elements in the form
        const selectElements = form.querySelectorAll('select');

        // Loop through each select element to check if a valid option is selected
        for (const select of selectElements) {
            if (select.value === '#') {
                alert('Please select an answer for all questions (a, b, c, or d).');
                event.preventDefault(); // Prevent the form from submitting
                return;
            }
        }
    });
});
</script>


<!-- JavaScript code here -->
<script>
// Get references to the elements
const profileIcon = document.getElementById('profile-icon');
const profileDialog = document.getElementById('profile-dialog');
const closeDialogBtn = document.getElementById('close-dialog'); // Added close button reference
const viewProfileBtn = document.getElementById('view-profile');

// Add a click event handler to the profile icon
profileIcon.addEventListener('click', () => {
    // Display the dialog box
    profileDialog.style.display = 'block';
});

// Add a click event handler to the "View Profile" button
viewProfileBtn.addEventListener('click', () => {
    window.location.replace('lecturer_profile.php');
});

// Add a click event handler to the "Close" button
closeDialogBtn.addEventListener('click', () => {
    // Close the dialog
    profileDialog.style.display = 'none';
});

</script>

</body>

</html>