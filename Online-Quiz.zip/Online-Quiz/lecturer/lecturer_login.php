<?php
include_once('../database.php');
session_start();

if (isset($_POST['submit'])) {

    $email = $_POST['email'];
    $pass = $_POST['password'];

    if (
        filter_var($email, FILTER_VALIDATE_EMAIL) &&
        strlen($pass) >= 8 &&
        strlen($pass) <= 20 &&
        preg_match('/^(?=.*[A-Z])(?=.*\d)/', $pass)  // Check for at least one uppercase letter and one number
    ) {

    $email = mysqli_real_escape_string($con, $_POST['email']);
    $pass = mysqli_real_escape_string($con, $_POST['password']); 

    $result = mysqli_query($con, "SELECT * FROM lecturer WHERE lecturer_email='$email'") or die('Error');

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_array($result);

        $hashed_password = $row['lecturer_password']; 

        if (password_verify($pass, $hashed_password)) {
            $_SESSION['logged'] = $email;
            $_SESSION['name'] = $row['lecturer_name'];
            $_SESSION['id'] = $row['lecturer_id'];
            $_SESSION['email'] = $row['lecturer_email'];

            echo "<script>alert('You have successfully logged in!'); window.location.replace('dashboard.php');</script>";
        } else {
            echo "<center><h3><script>alert('Sorry.. Wrong Username (or) Password');</script></h3></center>";
           header("refresh:0;url=lecturer_login.php");
        }
    } else {
        echo "<center><h3><script>alert('Sorry.. Wrong Username (or) Password');</script></h3></center>";
        header("refresh:0;url=lecturer_login.php");
    }
}else {
    echo"<script>alert('Validation failed: Email, password length, uppercase letter, and number requirements not met.'); </script>";
}
}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Lecturer Login | Online Quiz System</title>
		<link rel="stylesheet" href="../scripts/bootstrap/bootstrap.min.css">
		<link rel="stylesheet" href="../scripts/ionicons/css/ionicons.min.css">
		<link rel="stylesheet" href="../css/form.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">

        <style type="text/css">
            body{
                  width: 100%;
                  background: url(../image/book.png) ;
                  background-position: center center;
                  background-repeat: no-repeat;
                  background-attachment: fixed;
                  background-size: cover;
                }
          </style>
	</head>

	<body>
        <section class="login first grey">
                <div class="container">
                <center><img src="../image/logo.png" alt="Logo" width="100" height="100" style="padding-top:0px;">
                <h1 class="font-effect-shadow-multiple" style="padding-bottom: 15px;">Online Quiz System</h1></center>	
                    <div class="box-wrapper">				
                        <div class="box box-border">
                            <div class="box-body">
                            <center><h2>Lecturer Login</h2></center><br/>
                                <form method="post" action="lecturer_login.php" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label>Enter Your Email:</label>
                                        <input type="email" name="email" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="fw">Enter Your Password:</label>
                                        <input type="password" name="password" class="form-control" required>
                                    </div> 
                                    <div class="form-group text-right">
                                        <button class="btn btnStyle btn-block" name="submit">Login</button>
                                    </div>
                                </form>
                            </div>
                            <a href="../index.php" style="padding-bottom:20px;"><center><span class="text-muted"><< Back to homepage </span></center></a>
                        </div>
                    </div>
                </div>
            </section>

		<script src="js/jquery.js"></script>
		<script src="scripts/bootstrap/bootstrap.min.js"></script>
	</body>
</html>