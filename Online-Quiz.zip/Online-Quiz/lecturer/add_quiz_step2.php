<?php
    include_once '../database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:login.php");
    }
    else
    {
        $name = $_SESSION["name"];
        $email = $_SESSION['email'];
        $id = $_SESSION['id'];
        include_once '../database.php';
    }

    //for temporarily storing the data from step 1 and send to step 3
    $quiz_title = $_POST['quiz_title'];
    $quiz_subject = $_POST['quiz_subject'];
    $correct = $_POST['correct'];
    $wrong = $_POST['wrong'];
    $diff_level = $_POST['diff_level'];
    $attempt = $_POST['attempt'];
    $quiz_visibility = $_POST['quiz_visibility'];
    $quiz_time = $_POST['quiz_time'];
    $quiz_image = $_POST['quiz_image'];

    if(isset($_POST['quiz_password'])){
        $quiz_password = $_POST['quiz_password'];
    }

    $_SESSION['quiz_title'] = $quiz_title;
    $_SESSION['quiz_subject'] = $quiz_subject;
    $_SESSION['correct'] = $correct;
    $_SESSION['wrong'] = $wrong;
    $_SESSION['diff_level'] = $diff_level;
    $_SESSION['attempt'] = $attempt;
    $_SESSION['quiz_visibility'] = $quiz_visibility;
    $_SESSION['quiz_time'] = $quiz_time;
    $_SESSION['quiz_password'] = $quiz_password;
    $_SESSION['quiz_image'] = $quiz_image;
    
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Quiz | Online Quiz System</title>
    <link  rel="stylesheet" href="../css/bootstrap.min.css"/>
    <link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
    <link rel="stylesheet" href="../css/welcome.css">
    <link  rel="stylesheet" href="../css/font.css">
    <link rel="stylesheet" href="../css/form.css">
    <script src="js/jquery.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js"  type="text/javascript"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>    

</head>

<body>

  <!-- Navigation Menu for Large Screens (Laptops) -->
  <nav class="navbar navbar-default title1 hidden-sd hidden-xs" id="tablet">
    <div class="container-fluid">
        <div class="navbar-header">
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Hidden dialog box -->
        <div id="profile-dialog" class="dialog-box">
            <button id="close-dialog" class="close-button">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
            </button>
            <br/>
            <p>Lecturer ID : <?php echo $id; ?></p>
            <h3><?php echo $name; ?></h3>
            <br/>
            <center><button id="view-profile">View Profile</button></center>
        </div>


<!-- Navigation Menu for Small Screens (Mobile) -->
<nav class="navbar navbar-default title1 hidden-lg">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mobile-menu" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        
        <div class="collapse navbar-collapse" id="mobile-menu">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Student</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
                    <li><a href="#" class="hover-underline-animation" ><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
                    <li><a href="#" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span>&nbsp;Remove Quiz</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
              </ul>
            </div>
        </div>
    </nav> 
    
    <div class="container">
        <div class="row">
            <div class="col-md-2 hidden-sd hidden-xs hidden-md" id="tablet">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav flex-column navbar-left">
                <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Student</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
                    <li><a href="#" class="hover-underline-animation" ><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
                    <li><a href="#" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span>&nbsp;Remove Quiz</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                </ul>
            </div>
            </div>
    
    <div class="col-md-10">
    
        <div class="row">
            <span class="title1">
                <h1 style="padding:10px;"><center>Create a new quiz</center></h1>
                <h2><center>Select the questions for the quiz</center></h2>
            </span>
        </div>
        
            <form method="POST" action="add_quiz_step3.php" method="POST">

        
            <div class="panel">
            <div class="row">
                <div class="col-md-12">
                    <!-- Table header -->
                    <div class="table-responsive">
                        <table class="table title1" id="myTable"> 
                            <thead>
                                <tr style="color: #0087ca;">
                                    <td><center><span class="glyphicon glyphicon-ok"></center></td>
                                    <td><center><b>Question ID</b></center></td>
                                    <td><center><b>Question</b></center></td>
                                    <td><center><b>Subject</b></center></td>
                                    <td><center><b>Number of choices</b></center></td>
                                    <td><center><b>Choices</b></center></td>
                                </tr>
                            </thead>    
                            </tr>
                
                <?php 
                    //show questions 
                    $result = mysqli_query($con,"SELECT * FROM questions WHERE subject='$quiz_subject'") or die('Error');
                    
                    // Outer loop to retrieve questions
                    while ($row = mysqli_fetch_array($result)) {
                        $question_id = $row['question_id'];
                        $subject = $row['subject'];
                        $question = $row['question'];
                        $choice = $row['choice'];

                        // Initialize an empty string to store the concatenated options
                        $final_choice = '';

                        // Query to get the answers from the "options" table for the current question
                        $result2 = mysqli_query($con, "SELECT * FROM options WHERE question_id = '$question_id'") or die('Error');

                        while ($optionRow = mysqli_fetch_array($result2)) {
                            $option = $optionRow['option'];
                            $final_choice .= $option . ', ';
                        }

                        // Remove the trailing comma and space
                        $final_choice = rtrim($final_choice, ', ');

                        echo '<tr data-subject="' . $subject . '">
                            <td><center><input type="checkbox" name="selected_rows[]" value="' . $question_id . '" ></center></td>
                            <td><center>'.$question_id.'</center></td>
                            <td><center>'.$question.'</center></td>
                            <td><center>'.$subject.'</center></td>
                            <td><center>'.$choice.'</center></td>
                            <td><center>'.$final_choice.'</center></td>
                        </tr>';
                    }
                ?>
            </table>
        </div>
    </div>

    <div class="row" style="padding:10px;">
        <div class="col-md-12">
            <div class="form-group">
                <label class="col-md-12 control-label" for=""></label>
                <div class="col-md-12"> 
                    <center><a href="quizzes.php" class="btn btnStyle" >Cancel</a>&nbsp; &nbsp; &nbsp;<input type="submit" value="Done" name="submit" class="btn btnStyle"/></center>
                </div>
            </div>
        </div>
    </div>

    </div>   
    </div>

<script>
// Get references to the elements
const profileIcon = document.getElementById('profile-icon');
const profileDialog = document.getElementById('profile-dialog');
const closeDialogBtn = document.getElementById('close-dialog'); // Added close button reference
const viewProfileBtn = document.getElementById('view-profile');

// Add a click event handler to the profile icon
profileIcon.addEventListener('click', () => {
    // Display the dialog box
    profileDialog.style.display = 'block';
});

// Add a click event handler to the "View Profile" button
viewProfileBtn.addEventListener('click', () => {
    window.location.replace('lecturer_profile.php');
});

// Add a click event handler to the "Close" button
closeDialogBtn.addEventListener('click', () => {
    // Close the dialog
    profileDialog.style.display = 'none';
});

</script>

</body>
</html>