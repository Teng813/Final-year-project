<?php
    include_once '../database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:login.php");
    }
    else
    {
        $name = $_SESSION["name"];
        $email = $_SESSION['email'];
        $id = $_SESSION['id'];
        include_once '../database.php';
    }

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Quiz | Online Quiz System</title>
    <link  rel="stylesheet" href="../css/bootstrap.min.css"/>
    <link  rel="stylesheet" href="../css/bootstrap-theme.min.css"/>    
    <link rel="stylesheet" href="../css/welcome.css">
    <link  rel="stylesheet" href="../css/font.css">
    <link rel="stylesheet" href="../css/form.css">
    <script src="js/jquery.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js"  type="text/javascript"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>   

<style>
    #quiz_password{
        display:none;
    }
    </style>
</head>

<body>

  <!-- Navigation Menu for Large Screens (Laptops) -->
  <nav class="navbar navbar-default title1 hidden-sd hidden-xs" id="tablet">
    <div class="container-fluid">
        <div class="navbar-header">
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
        </div>
    </div>
</nav>

        <!-- Hidden dialog box -->
        <div id="profile-dialog" class="dialog-box">
            <button id="close-dialog" class="close-button">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
            </button>
            <br/>
            <p>Lecturer ID : <?php echo $id; ?></p>
            <h3><?php echo $name; ?></h3>
            <br/>
            <center><button id="view-profile">View Profile</button></center>
        </div>


<!-- Navigation Menu for Small Screens (Mobile) -->
<nav class="navbar navbar-default title1 hidden-lg">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#mobile-menu" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <img src="../image/logo.png" width="50px" height="50px" style="margin-left:5px;">
            <a class="navbar-brand" href="admin_dashboard.php" style="display: inline-block; font-family:Sofia, sans-serif;"><b>Online Quiz System</b></a>
        </div>
        
        <div class="collapse navbar-collapse" id="mobile-menu">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="user-profile">
                        <span class="glyphicon glyphicon-user" aria-hidden="true" id="profile-icon"></span>
                    </div>
                </li>
                <li> <a href="../logout.php?q=index.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
              <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Student</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
                    <li><a href="#" class="hover-underline-animation" ><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
                    <li><a href="#" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span>&nbsp;Remove Quiz</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
              </ul>
            </div>
        </div>
    </nav> 
    
    <div class="container">
        <div class="row">
            <div class="col-md-2 hidden-sd hidden-xs hidden-md" id="tablet">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav flex-column navbar-left">
                <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>&nbsp;Student</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-folder-close" aria-hidden="true"></span>&nbsp;Question Bank</a></li>
                    <li><a href="#" class="hover-underline-animation" ><span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Subject</a></li>
                    <li><a href="#" class="hover-underline-animation" style="color: #c8081c;"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>&nbsp;Quizzes</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span>&nbsp;Remove Quiz</a></li>
                    <li><a href="#" class="hover-underline-animation"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Profile</a></li>
                </ul>
            </div>
            </div>
    
    
            <?php
                $quiz_id=@$_GET['quiz_id'];
            ?>

            <div class="col-md-10">
            <span class="title1">
                <center><h1 style="padding:10px;">Edit Quiz</h1></center>
            <span> 
        
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">  
                    <div class="form-group">
                        <label class="col-md-12 control-label" for="quiz_id">Quiz ID :</label>
                        <div class="col-md-12">
                            <input id="quiz_id" name="quiz_id" value="<?php echo $quiz_id; ?>" class="form-control input-md" type="text" readonly>
                        </div>
                    </div>
                </div><div class="col-md-3"></div>
            </div>

            <form class="title1" name="form" action="edit_quiz_step2.php?quiz_id=<?php echo $quiz_id;?>"  method="POST">
                <fieldset>

                <?php
                //initialize data
                $quiz_title = '';
                $correct = '';
                $wrong = '';
                $diff_level = '';
                $attempt = '';
                $quiz_time = '';

                // Read old data from the announcement table
                $result = mysqli_query($con, "SELECT * FROM quiz WHERE quiz_id = $quiz_id") or die('Error');
                while ($row = mysqli_fetch_array($result)) {
                    $quiz_title = $row['quiz_title'];
                    $correct = $row['correct'];
                    $wrong = $row['wrong'];
                    $diff_level = $row['diff_level'];
                    $attempt = $row['attempt'];
                    $quiz_time = $row['quiz_time'];
                    $quiz_subject = $row['quiz_subject'];
                    $quiz_visibility = $row['quiz_visibility'];
                    $quiz_image = $row['quiz_image'];
                }
                

                //hidden input for saving quiz subject
                echo"<input type='hidden' id='quiz_subject' name='quiz_subject' value='$quiz_subject' class='form-control input-md'>";
                ?>

                <div class="row" style="padding:10px;">   
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for="old_quiz_image">Old quiz image : </label>  
                            <div class="col-md-12">
                                <input type="hidden" name="old_quiz_image" value="<?php echo $quiz_image; ?>">
                                <img src="../image/<?php echo $quiz_image; ?>" alt="Profile Picture" width="100%" height="250">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for="quiz_image">Upload the new quiz image :</label>
                            <div class="col-md-12">
                                <input type="file" id="fileName" name="quiz_image" class="btn btnStyle" style="width:100%;" accept=".jpg,.jpeg,.png,.gif" onchange="validateFileType(this)" />
                         
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row" style="padding:10px;">   
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for="old_quiz_title">Old quiz title : </label>  
                            <div class="col-md-12">
                                <input type="text" id="old_quiz_title" name="old_quiz_title" value="<?php echo $quiz_title;?>" class="form-control input-md" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for="quiz_title">Enter the new quiz title :</label>
                            <div class="col-md-12">
                                <input id="quiz_title" name="quiz_title" placeholder="Please enter the new quiz title" class="form-control"></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row"  style="padding:10px;">   
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for="old_correct">Old correct mark : </label>  
                            <div class="col-md-12">
                                <input  type="number" id="old_correct" name="old_correct" value=<?php echo $correct;?> class="form-control input-md" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for="correct">Enter the new correct mark :</label>
                            <div class="col-md-12">
                                <input  type="number" id="correct" name="correct" placeholder="Please enter the new correct mark" class="form-control"></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row" style="padding:10px;">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for="old_wrong">Old wrong mark : </label>  
                            <div class="col-md-12">
                                <input type="number" id="old_wrong" name="old_wrong" value="<?php echo $wrong; ?>" class="form-control input-md" type="text" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-md-12 control-label" for="wrong">Enter the new wrong mark :</label>
                                <div class="col-md-12">
                                    <input  type="number" id="wrong" name="wrong" placeholder="Please enter the new wrong mark" class="form-control input-md" type="text" >
                                </div>
                            </div>
                    </div>
                </div>

                <div class="row" style="padding:10px;">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for="old_diff_level">Old difficulty level ( out of 10 ) : </label>  
                            <div class="col-md-12">
                                <input type="number" id="old_diff_level" name="old_diff_level" value="<?php echo $diff_level; ?>" class="form-control input-md" type="text" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-md-12 control-label" for="diff_level">Enter the new difficulty level ( out of 10 ) :</label>
                                <div class="col-md-12">
                                    <input type="number" id="diff_level" name="diff_level" placeholder="Please enter the new difficulty level ( out of 10 )" class="form-control input-md" type="text" >
                                </div>
                            </div>
                    </div>
            </div>

                <div class="row" style="padding:10px;">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for="old_attempt">Old number of attempt : </label>  
                            <div class="col-md-12">
                                <input type="number" id="old_attempt" name="old_attempt" value="<?php echo $attempt; ?>" class="form-control input-md" type="text" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-md-12 control-label" for="attempt">Enter the new number of attempt:</label>
                                <div class="col-md-12">
                                    <input type="number" id="attempt" name="attempt" placeholder="Please enter the new number of attempt" class="form-control input-md" type="text" >
                                </div>
                            </div>
                    </div>
                </div>

                <div class="row" style="padding:10px;">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for="old_quiz_time">Old time limit : </label>  
                            <div class="col-md-12">
                                <input type="number" id="old_quiz_time" name="old_quiz_time" value="<?php echo $quiz_time; ?>" class="form-control input-md" type="text" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-md-12 control-label" for="quiz_time">Enter the new time limit :</label>
                                <div class="col-md-12">
                                    <input type="number" id="quiz_time" name="quiz_time" placeholder="Please enter the new time limit" class="form-control input-md" type="text" >
                                </div>
                            </div>
                    </div>
                </div>

                <div class="row" style="padding:10px;">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for="old_visibility">Old quiz visibility : </label>  
                            <div class="col-md-12">
                                <input id="old_visibility" name="old_visibility" value="<?php echo $quiz_visibility; ?>" class="form-control input-md" type="text" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for="quiz_visibility">Enter the new quiz visibility:</label>
                            <div class="col-md-12">
                            <select id="quiz_visibility" name="quiz_visibility" class="form-control input-md" >
                                <option value="#">Please select visibility of the quiz</option>
                                <option value="Private">Private</option>
                                <option value="Public">Public</option>
                            </select>
                             
                        </div>
                    </div>
                </div>
                    
                <div class="row" style="padding:10px;">
                    <div class="col-md-6"></div>

                    <div class="col-md-6">
                    <div class="form-group" id="quiz_password" >
                        <label class="col-md-12 control-label" for="quiz_password">Enter the password of the private quiz :</label>  
                        <div class="col-md-12">
                            <input name="quiz_password" placeholder="Enter the password of the private quiz " class="form-control input-md" type="text">
                        </div>
                    </div>
                    </div>
                </div>

                <div class="row" style="padding:10px;">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-12 control-label" for=""></label>
                            <div class="col-md-12"> 
                                <center><a href="quizzes.php" class="btn btnStyle" >Cancel</a>&nbsp; &nbsp; &nbsp;<input type="submit" value="Next" name="submit" class="btn btnStyle"/></center>
                            </div>
                        </div>
                    </div>
                </div>

                </fieldset>
            </form>
        </div>
       
    </div>

<script type="text/javascript">
  function validateFileType(input) {
    var fileName = input.value;
    var idxDot = fileName.lastIndexOf(".") + 1;
    var extFile = fileName.substr(idxDot, fileName.length).toLowerCase();

    if (extFile == "jpg" || extFile == "jpeg" || extFile == "png" || extFile == "gif") {
      // File is valid. You can add further processing here.
    } else {
      alert("Only jpg, jpeg, png, and gif files are allowed!");

      // Delay clearing the input for a few milliseconds
      setTimeout(function() {
        input.value = ''; // Clear the input field
      }, 100);

      // Note: You can adjust the delay (100 milliseconds in this example) as needed.
    }
  }
</script>


    <script>
        // Initially hide the password input
        $(document).ready(function () {
            if ($('#quiz_visibility').val() !== 'Private') {
                $('#quiz_password').hide();
            }
        });

        $('#quiz_visibility').on('change', function () {
            if (this.value === 'Private') {
                $('#quiz_password').show();
            } else {
                $('#quiz_password').hide();
            }
        });
    </script>


    <script>
// Get references to the elements
const profileIcon = document.getElementById('profile-icon');
const profileDialog = document.getElementById('profile-dialog');
const closeDialogBtn = document.getElementById('close-dialog'); // Added close button reference
const viewProfileBtn = document.getElementById('view-profile');

// Add a click event handler to the profile icon
profileIcon.addEventListener('click', () => {
    // Display the dialog box
    profileDialog.style.display = 'block';
});

// Add a click event handler to the "View Profile" button
viewProfileBtn.addEventListener('click', () => {
    window.location.replace('lecturer_profile.php');
});

// Add a click event handler to the "Close" button
closeDialogBtn.addEventListener('click', () => {
    // Close the dialog
    profileDialog.style.display = 'none';
});

</script>

</body>
</html>